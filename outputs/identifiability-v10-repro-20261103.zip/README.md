# v10 原始脚本可复现包
解压后执行 python identifiability_v10.py。source_free_bound_v5.py 是仓库存档的 v5 版本，保留原名以满足上传脚本的 import。248 行日志可复现；解释请读同仓库 identifiability-v10-review-20261103.md。
