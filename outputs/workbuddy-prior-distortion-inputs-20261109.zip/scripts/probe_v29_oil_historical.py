# -*- coding: utf-8 -*-
"""
probe_v29_oil.py -- the oil side, after the v28 audit.

v28 turned "temperature is a prior" into a predicate, then wrote the
predicate's actuator as an oil flow of 0.106-0.286 kg/s evaluated with
Dittus-Boelter.  The audit points out that those points have Re 2808-7594,
i.e. below the correlation's own floor.  That is correct and it voids the
number, not just its label.

This script does five things:
  [1] the annulus Reynolds ceiling: why changing the GAP cannot rescue the
      low-flow branch.  Closed form, then a table, then the procurement
      flow as a function of the oil viscosity (the real unknown).
  [2] the audit's 0.50 kg/s branch, reproduced, plus the two things it did
      not report: the makeup flow (the chiller does NOT see 0.50 kg/s) and
      the control authority left over at each end of the power window.
  [3] the 6 kW reconciliation, four rows, reproduced from this solver.
  [4] the currency sentence, corrected: 20 pct is the LOSS, not Q_net.
  [5] parallel tubes at fixed total flow: per-tube Re, and why the n^0.2
      table has to be withdrawn rather than qualified.

ASCII log only.  No percent formatting: strings use .format, literal
percent signs are written as 'pct'.
"""

import math
import os

LOG = []


def L(s):
    LOG.append(s)


def rule(c="-", n=78):
    L(c * n)


# ---------------------------------------------------------------- properties
def rho(T):
    return 11065.0 - 1.293 * T


def cp(T):
    return 164.8 - 3.94e-2 * T + 1.25e-5 * T * T - 4.56e5 / (T * T)


def mu(T):
    return 4.94e-4 * math.exp(754.1 / T)


def kk(T):
    return 3.284 + 1.617e-2 * T - 2.305e-6 * T * T


def beta(T):
    return 1.293 / rho(T)


# ---------------------------------------------------------------- declaration
D_M = 0.016
D_O = 0.020
A_M = math.pi * D_M ** 2 / 4.0
H_M = 2.00
L_TOT = 16.00
U_INS = 0.17574312024704186
INS_LEN = 16.04 - 0.99
BRIDGE = 0.5
T_AMB = 293.15
K_WALL = 15.0
R_I, R_O = D_M / 2.0, D_O / 2.0

T_IN_REF = 473.15
T_CIN = 433.15
M_OIL = 0.148
CP_OIL = 2300.0
RHO_O, MU_O, K_O = 750.0, 1.0e-3, 0.12
PR_O = MU_O * CP_OIL / K_O
GAP = 0.004
DH_O = 2.0 * GAP
A_O = math.pi / 4.0 * ((D_O + 2.0 * GAP) ** 2 - D_O ** 2)
H_I_FROZEN = 4969.0


def churchill(re, rel_rough=0.0):
    inner = (7.0 / re) ** 0.9 + 0.27 * rel_rough
    a = (2.457 * math.log(1.0 / inner)) ** 16
    b = (37530.0 / re) ** 16
    return 8.0 * ((8.0 / re) ** 12 + (a + b) ** -1.5) ** (1.0 / 12.0)


def orifice_nea(d_main, d_hole):
    s = d_hole / d_main
    return (1.0 / s ** 2) * (1.0 - s ** 2) + (1.0 - s ** 2) ** 2 + 0.5 * (1.0 - s ** 2)


def elbow_mitre(re):
    return 427.5 * re ** -0.77 + 0.9


def q_loss(t_hot):
    return (U_INS * INS_LEN + BRIDGE) * (t_hot - T_AMB)


def K_of(m, t_avg, eps, k_aux, hole=0.010):
    re = 4.0 * m / (math.pi * D_M * mu(t_avg))
    kp = churchill(re, eps / D_M) * L_TOT / D_M
    ke = 4.0 * elbow_mitre(re)
    ko = orifice_nea(D_M, hole) if hole else 0.0
    return kp + ke + ko + k_aux


def solve(q_e, t_in, eps=10e-6, k_aux=0.5, qfix=None):
    """v28 loop, verbatim, with the two audit knobs exposed."""
    q_net = q_e - 600.0
    d_t = 60.0
    mass = 0.25
    t_avg = t_in
    for _ in range(600):
        t_avg = t_in + 0.5 * d_t
        k_use = K_of(mass, t_avg, eps, k_aux)
        u = (2.0 * 9.81 * beta(t_avg) * H_M * q_net
             / (k_use * rho(t_avg) * A_M * cp(t_avg))) ** (1.0 / 3.0)
        mass = rho(t_avg) * A_M * u
        d_t = q_net / (mass * cp(t_avg))
        t_max = t_in + d_t
        q_net_new = q_e - q_loss(t_max) if qfix is None else q_e - qfix
        if abs(q_net_new - q_net) < 1e-10:
            break
        q_net = q_net_new
    return q_net, mass, d_t, t_max, t_avg


def h_i_of(mass, t_avg):
    pe = 4.0 * mass * cp(t_avg) / (math.pi * D_M * kk(t_avg))
    nu = 5.9 + 0.015 * pe ** 0.8
    return nu * kk(t_avg) / D_M


def ua_from(h_i, h_o, length=1.0):
    inv = 1.0 / h_i + (R_I / K_WALL) * math.log(R_O / R_I) + (R_I / R_O) / h_o
    return math.pi * D_M * length / inv


def re_annulus(m_oil, gap, mu_o=MU_O, d_i=D_O):
    """Re = 4 m / (pi mu (D_i + D_o)); hydraulic diameter cancels exactly."""
    return 4.0 * m_oil / (math.pi * mu_o * (d_i + d_i + 2.0 * gap))


def h_o_db(m_oil, gap, mu_o=MU_O, rho_o=RHO_O):
    dh = 2.0 * gap
    area = math.pi / 4.0 * ((D_O + 2.0 * gap) ** 2 - D_O ** 2)
    v = m_oil / (rho_o * area)
    re = rho_o * v * dh / mu_o
    pr = mu_o * CP_OIL / K_O
    nu = 0.023 * re ** 0.8 * pr ** 0.4
    return nu * K_O / dh, re, v


# ==================================================== [1] the Re ceiling
rule("=")
L("[1] the annulus Reynolds ceiling: the gap cannot rescue the low flow")
L("")
L("  A = pi/4 (Do^2 - Di^2) = pi/4 (Do-Di)(Do+Di),  Dh = Do-Di, so")
L("      Re = rho v Dh / mu = 4 m / [pi mu (Di + Do)].        (exact)")
L("  The gap cancels out of the numerator.  As Do -> Di the ceiling is")
L("      Re_max = 2 m / (pi mu Di),                            (exact)")
L("  reached only by a vanished annulus.  Widening the gap LOWERS Re.")
L("")
L("  Di = {:.0f} mm, mu = {:.1e} Pa s.  Re at four flows:".format(D_O * 1e3, MU_O))
L("")
L("{:>8s}{:>8s}{:>9s}{:>9s}{:>9s}{:>9s}".format(
    "gap mm", "Dh mm", "0.106", "0.148", "0.286", "0.500"))
for g_mm in (1.0, 2.0, 4.0, 8.0, 16.0):
    g = g_mm * 1e-3
    vals = [re_annulus(m, g) for m in (0.106, 0.148, 0.286, 0.500)]
    L("{:8.1f}{:8.1f}{:9.0f}{:9.0f}{:9.0f}{:9.0f}".format(
        g_mm, 2 * g_mm, vals[0], vals[1], vals[2], vals[3]))
L("{:>8s}{:>8s}{:9.0f}{:9.0f}{:9.0f}{:9.0f}".format(
    "-> 0", "-> 0", re_annulus(0.106, 0.0), re_annulus(0.148, 0.0),
    re_annulus(0.286, 0.0), re_annulus(0.500, 0.0)))
L("")
L("  -> at 0.106 kg/s the whole family of gaps spans Re 1875-3374: not one")
L("     of them reaches the 1e4 floor of Dittus-Boelter.  The audit's 3374")
L("     is the ceiling, and it is a geometric impossibility, not a choice.")
L("  -> at 0.286 kg/s the 4 mm gap gives Re 7594; the ceiling is 9104.  Still")
L("     short.  So BOTH ends of the v28 range are out, not just the low end.")
L("")
L("  the flow actually required, as a function of the gap:")
L("")
L("{:>8s}{:>14s}{:>10s}".format("gap mm", "m for Re=1e4", "v m/s"))
for g_mm in (1.0, 2.0, 4.0, 8.0, 16.0):
    g = g_mm * 1e-3
    m_need = 1e4 * math.pi * MU_O * (D_O + D_O + 2.0 * g) / 4.0
    area = math.pi / 4.0 * ((D_O + 2.0 * g) ** 2 - D_O ** 2)
    L("{:8.1f}{:14.3f}{:10.2f}".format(g_mm, m_need, m_need / (RHO_O * area)))
m_floor = 1e4 * math.pi * MU_O * (2.0 * D_O) / 4.0
L("")
L("  -> 0.377 kg/s at the declared 4 mm gap; {:.3f} kg/s is the absolute".format(m_floor))
L("     floor (gap -> 0).  So no drawing revision of the annular gap can")
L("     turn 0.106 kg/s into a Dittus-Boelter point.  Only flow can.")
L("")
L("  and the flow is linear in the viscosity, which is the real unknown:")
L("")
L("{:>14s}{:>14s}{:>14s}".format("mu x 1e-3", "m for Re=1e4", "note"))
for f in (0.6, 1.0, 1.5, 2.0, 3.0):
    mu_o = f * 1e-3
    m_need = 1e4 * math.pi * mu_o * (D_O + D_O + 2.0 * GAP) / 4.0
    note = "declared" if abs(f - 1.0) < 1e-9 else ""
    L("{:14.1f}{:14.3f}{:>14s}".format(f, m_need, note))
L("")
L("  mu_o is a placeholder (1.0e-3 Pa s) with no grade attached.  If the")
L("  chosen oil is 2e-3 at 460 K -- entirely ordinary for a mineral oil --")
L("  the flow doubles again to 0.75 kg/s.  The procurement item is the")
L("  mu(T) curve over 433-473 K, not the flow.  Freeze the curve, then the")
L("  flow follows from this line.")
L("")

# ============================================= [2] the 0.50 kg/s branch
rule("=")
L("[2] the audit's 0.50 kg/s branch, reproduced and extended")
L("")
M2 = 0.50


def hold_tin(q_e, m_oil, t_tgt=T_IN_REF, ua_scale=1.0):
    """T_cin that makes the loop sit exactly at t_tgt, with UA from the channel."""
    qn, mass, d_t, t_max, t_avg = solve(q_e, t_tgt)
    h_i = h_i_of(mass, t_avg)
    h_o, re_o, v_o = h_o_db(m_oil, GAP)
    ua = ua_from(h_i, h_o) * ua_scale
    t_cout_of = lambda tc: tc + qn / (m_oil * CP_OIL)

    def resid(tc):
        a = t_max - t_cout_of(tc)
        b = t_tgt - tc
        if a <= 0.0 or b <= 0.0:
            return -1e9
        lmtd = (a - b) / math.log(a / b)
        return ua * lmtd - qn

    lo, hi = T_CIN, t_tgt - 1e-6
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if resid(mid) > 0.0:
            lo = mid
        else:
            hi = mid
    tc = 0.5 * (lo + hi)
    a = t_max - t_cout_of(tc)
    b = t_tgt - tc
    lmtd = (a - b) / math.log(a / b)
    x_cold = m_oil * (t_cout_of(tc) - tc) / (t_cout_of(tc) - T_CIN)
    return dict(q=qn, m_lbe=mass, dt=d_t, tmax=t_max, tav=t_avg, h_i=h_i,
                h_o=h_o, re_o=re_o, v_o=v_o, ua=ua, t_cin=tc,
                t_cout=t_cout_of(tc), lmtd=lmtd, approach=b, scale=ua_scale,
                x_cold=x_cold, q_chill=x_cold * CP_OIL * (t_cout_of(tc) - T_CIN))


L("  m_oil {:.2f} kg/s, 4 mm annulus, 1.00 m, cold supply {:.2f} K,".format(M2, T_CIN))
L("  target T_H,in {:.2f} K:".format(T_IN_REF))
L("")
L("{:>7s}{:>9s}{:>9s}{:>8s}{:>8s}{:>9s}{:>8s}{:>10s}".format(
    "Q kW", "T_cin", "T_cout", "UA", "h_o", "Re_oil", "LMTD", "approach"))
br = {}
for qe in (3000.0, 4300.0, 5000.0, 6000.0):
    st = hold_tin(qe, M2)
    br[qe] = st
    L("{:7.1f}{:9.1f}{:9.1f}{:8.1f}{:8.0f}{:9.0f}{:8.1f}{:10.1f}".format(
        qe / 1e3, st["t_cin"], st["t_cout"], st["ua"], st["h_o"],
        st["re_o"], st["lmtd"], st["approach"]))
L("")
L("  audit quotes 466.5 / 468.4 / 73.2 at 3 kW and 450.2 / 454.6 / 74.7 at")
L("  6 kW.  Row for row above, within rounding.  Nothing to arbitrate.")
L("")
L("  Re {:.0f} at 0.50 kg/s: {:.0f} pct above the 1e4 floor, and the flow is".format(
    br[3000.0]["re_o"], 100.0 * (br[3000.0]["re_o"] / 1e4 - 1.0)))
L("  {:.0f} pct above the {:.3f} kg/s minimum for that floor.  So 0.50 is not".format(
    100.0 * (M2 / 0.377 - 1.0), 0.377))
L("  a tuned value, it is the first round number above the validity boundary.")
L("")
L("  what the audit did not report -- the loop is flow-rich:")
L("")
L("{:>7s}{:>10s}{:>11s}{:>10s}{:>10s}".format(
    "Q kW", "dT_oil K", "m makeup", "cold pct", "Q chiller"))
for qe in (3000.0, 4300.0, 5000.0, 6000.0):
    st = br[qe]
    L("{:7.1f}{:10.2f}{:11.4f}{:10.1f}{:10.0f}".format(
        qe / 1e3, st["t_cout"] - st["t_cin"], st["x_cold"],
        100.0 * st["x_cold"] / M2, st["q_chill"]))
L("")
L("  -> the oil rises only 1.9-4.4 K across the exchanger, because 0.50 kg/s")
L("     is 3.4x the flow the duty needs.  The 0.50 kg/s is a RECIRCULATION")
L("     loop: the chiller sees only the makeup, {:.3f}-{:.3f} kg/s, i.e.".format(
    br[3000.0]["x_cold"], br[6000.0]["x_cold"]))
L("     {:.0f}-{:.0f} pct of it, and rejects {:.1f}-{:.1f} kW.  Two different".format(
    100.0 * br[3000.0]["x_cold"] / M2, 100.0 * br[6000.0]["x_cold"] / M2,
    br[3000.0]["q_chill"] / 1e3, br[6000.0]["q_chill"] / 1e3))
L("     procurement lines, and conflating them over-sizes the chiller 10x.")
L("")
_v2 = h_o_db(M2, GAP)[2]
_f2 = churchill(13263.0)
_dp2 = _f2 * (1.0 / DH_O) * RHO_O * _v2 * _v2 / 2.0
L("  hydraulics are not the obstacle: v {:.2f} m/s, f {:.4f}, dP {:.1f} kPa over".format(
    _v2, _f2, _dp2 / 1e3))
L("  the 1 m test section, pump {:.1f} W.  The constraint is the correlation,".format(
    M2 * _dp2 / RHO_O))
L("  not the pump -- worth saying, because it inverts the usual objection to")
L("  raising oil flow.")
L("")
L("  the control law this implies, T_cin against power:")
L("     {:.1f} K at 3 kW, {:.1f} K at 6 kW -- it FALLS with power, and the".format(
    br[3000.0]["t_cin"], br[6000.0]["t_cin"]))
L("     cold fraction rises {:.0f} -> {:.0f} pct.  Mixing valve authority".format(
    100.0 * br[3000.0]["x_cold"] / M2, 100.0 * br[6000.0]["x_cold"] / M2))
L("     {:.1f}:1 in makeup, which is an ordinary three-way valve.".format(
    br[6000.0]["x_cold"] / br[3000.0]["x_cold"]))
L("")
L("  and the authority left over -- T_H,in reachable at each end, holding")
L("  T_cin at the two limits:")
L("")
L("{:>7s}{:>14s}{:>14s}{:>12s}".format(
    "Q kW", "T_in @433.15", "T_in @req", "authority K"))
t_low = {}
for qe in (3000.0, 6000.0):
    qn, mass, d_t, t_max, t_avg = 0.0, 0.0, 0.0, 0.0, 0.0
    # at T_cin = 433.15 the exchanger takes what it can; iterate T_in
    lo, hi = 400.0, 520.0
    for _ in range(160):
        mid = 0.5 * (lo + hi)
        qn, mass, d_t, t_max, t_avg = solve(qe, mid)
        h_i = h_i_of(mass, t_avg)
        h_o = h_o_db(M2, GAP)[0]
        ua = ua_from(h_i, h_o)
        t_cout = T_CIN + qn / (M2 * CP_OIL)
        a, b = t_max - t_cout, mid - T_CIN
        if a <= 0.0 or b <= 0.0:
            lo = mid
            continue
        lmtd = (a - b) / math.log(a / b)
        if ua * lmtd > qn:
            hi = mid
        else:
            lo = mid
    t_lo = 0.5 * (lo + hi)
    t_low[qe] = t_lo
    L("{:7.1f}{:14.1f}{:14.1f}{:12.1f}".format(
        qe / 1e3, t_lo, T_IN_REF, T_IN_REF - t_lo))
L("")
L("  -> at 3 kW, cold oil alone takes T_in down to {:.1f} K, i.e. {:.1f} K".format(
    t_low[3000.0], T_IN_REF - t_low[3000.0]))
L("     BELOW the target.  So the controller has authority in both")
L("     directions: it can warm into the band and it can cool below it.")
L("     The v28 flow-only branch could not reach the band at 3 kW even at")
L("     full cold; this one overshoots it, which is what a controller needs.")
L("     Direction check: T_cin FALLS as power rises, so the failure mode is")
L("     a valve stuck cold, not stuck warm.")
L("")

L("  does the oil-side correlation error reach the FoM?  No -- it eats")
L("  control margin instead.  Hold T_H,in at 473.15 K and degrade UA:")
L("")
L("{:>8s}{:>10s}{:>10s}{:>12s}{:>10s}".format(
    "UA x", "UA W/K", "T_cin", "approach K", "makeup"))
for f in (1.00, 0.92, 0.85, 0.80, 0.77):
    st = hold_tin(6000.0, M2, ua_scale=f)
    L("{:8.2f}{:10.1f}{:10.1f}{:12.1f}{:10.4f}".format(
        f, st["ua"], st["t_cin"], st["approach"], st["x_cold"]))
lo, hi = 0.3, 1.0
for _ in range(80):
    mid = 0.5 * (lo + hi)
    st = hold_tin(6000.0, M2, ua_scale=mid)
    if st["t_cin"] > T_CIN + 1e-9:
        hi = mid
    else:
        lo = mid
f_lim = 0.5 * (lo + hi)
f_lim3 = None
lo3, hi3 = 0.2, 1.0
for _ in range(80):
    mid = 0.5 * (lo3 + hi3)
    st = hold_tin(3000.0, M2, ua_scale=mid)
    if st["t_cin"] > T_CIN + 1e-9:
        hi3 = mid
    else:
        lo3 = mid
f_lim3 = 0.5 * (lo3 + hi3)
L("")
L("  -> at 6 kW the controller absorbs a UA deficit down to {:.0f} pct of".format(
    100.0 * f_lim))
L("     nominal before the mixing valve saturates at {:.2f} K.  A".format(T_CIN))
L("     Dittus-Boelter residual of 10-15 pct is well inside that.  So the")
L("     oil-side correlation error is NOT an input uncertainty for D_m: it")
L("     is absorbed by T_cin, and becomes a FoM input only if the actuator")
L("     saturates -- a different and checkable failure.")
L("     That is the answer to 'may the 8.7 pct RMS enter the GSA': not for")
L("     h_o, because h_o is not what the FoM sees.")
L("     The binding end is 6 kW: {:.0f} pct there against {:.0f} pct at 3 kW.".format(
    100.0 * f_lim, 100.0 * f_lim3))
L("")

# ================================================ [3] the 6 kW reconciliation
rule("=")
L("[3] the 6 kW flow: four rows, from this solver")
L("")
L("  T_H,in 473.15 K, K(Re) live, 16 m, 4 elbows, 10 mm orifice present.")
L("  Each row changes only what it names.  Conditional, not a decomposition.")
L("")
L("{:>44s}{:>10s}{:>9s}".format("condition", "m kg/s", "Q_loss W"))
rows = [
    ("v28: eps 10 um, K_aux 0.5, lumped loss", dict(eps=10e-6, k_aux=0.5)),
    ("no roughness, K_aux 0.5", dict(eps=0.0, k_aux=0.5)),
    ("smooth and K_aux 0", dict(eps=0.0, k_aux=0.0)),
    ("smooth, K_aux 0, 795 W along-path loss", dict(eps=0.0, k_aux=0.0, qfix=795.0)),
]
res = []
for name, kw in rows:
    qn, mass, d_t, t_max, t_avg = solve(6000.0, T_IN_REF, **kw)
    res.append((name, mass, 6000.0 - qn))
    L("{:>44s}{:10.6f}{:9.0f}".format(name, mass, 6000.0 - qn))
L("{:>44s}{:10.6f}{:9.0f}".format("independent 1D along-path audit", 0.273200, 795))
L("")
L("  audit rows: 0.265118 / 0.267891 / 0.269194 / 0.272702 / 0.273200.")
L("  above:      {:.6f} / {:.6f} / {:.6f} / {:.6f}.".format(
    res[0][1], res[1][1], res[2][1], res[3][1]))
gap_pp = 100.0 * (0.273200 / res[3][1] - 1.0)
L("  -> reproduced to the last digit.  Aligning roughness, auxiliary drag and")
L("     loss bookkeeping closes the gap to {:.3f} pct, and the remainder is".format(abs(gap_pp)))
L("     the difference between a lumped T_max and an integrated profile --")
L("     not a new property of LBE and not a missing mechanism.")
L("")
L("  the three prices of the alignment, in the same units:")
L("")
for i in range(1, 4):
    d = 100.0 * (res[i][1] / res[i - 1][1] - 1.0)
    L("     step {}: {:+.2f} pct of flow  ({} )".format(i, d, rows[i][0]))
L("")
L("  -> heat-loss bookkeeping is the largest single step, {:.0f} pct of the".format(
    100.0 * (res[3][1] - res[2][1]) / (res[3][1] - res[0][1])))
L("     total correction.  That is the same ordering as the temperature")
L("     experiment in v28, from a different direction.  Consistent.")
L("")

# ================================================== [4] the currency, fixed
rule("=")
L("[4] the currency sentence, corrected")
L("")
L("  v28 wrote 'q_net ... is 20 pct of Q'.  Wrong way round: 20 pct is the")
L("  LOSS.  Measured at T_in 473.15 K:")
L("")
L("{:>7s}{:>10s}{:>10s}{:>10s}{:>11s}".format(
    "Q kW", "Q_net", "Q_loss", "loss pct", "3pct Q_net"))
for qe in (3000.0, 4300.0, 5000.0, 6000.0):
    qn, mass, d_t, t_max, t_avg = solve(qe, T_IN_REF)
    L("{:7.1f}{:10.0f}{:10.0f}{:10.1f}{:11.0f}".format(
        qe / 1e3, qn, qe - qn, 100.0 * (qe - qn) / qe, 0.03 * qn))
L("")
L("  -> at 4.3 kW, Q_net is {:.2f} kW and 3 pct of it is {:.0f} W, not 130 W.".format(
    solve(4300.0, T_IN_REF)[0] / 1e3, 0.03 * solve(4300.0, T_IN_REF)[0]))
L("  -> and the exchange rate itself is local.  With K(Re) live the exponent")
L("     is not 1/3 but 1/(3 + dlnK/dlnm) = 1/{:.3f}, so 1 pct of flow costs".format(
    3.0 - 0.2345))
L("     {:.2f} pct of Q_net here, {:.0f} W at 4.3 kW.".format(
    3.0 - 0.2345, (3.0 - 0.2345) * 0.01 * solve(4300.0, T_IN_REF)[0]))
L("     Quote it as a local magnitude at a named power, never as an identity.")
L("")

# =============================================== [5] parallel tubes
rule("=")
L("[5] parallel tubes at fixed total flow -- withdraw, do not qualify")
L("")
L("  v28 [5] scaled UA as n^0.2 at fixed total oil flow and concluded that")
L("  150 W/K needs about 1e2 tubes.  The exponent is what Dittus-Boelter")
L("  gives; the per-tube Re is what kills it:")
L("")
L("{:>4s}{:>11s}{:>10s}{:>10s}{:>10s}{:>10s}".format(
    "n", "m/tube", "Re/tube", "h_o turb", "UA tot", "regime"))
for n in (1, 2, 4, 8, 16):
    mt = M_OIL / n
    h_o, re_t, v_t = h_o_db(mt, GAP)
    ua_t = ua_from(H_I_FROZEN, h_o)
    reg = "turb" if re_t >= 1e4 else ("trans" if re_t > 2300 else "LAMINAR")
    L("{:4d}{:11.4f}{:10.0f}{:10.0f}{:10.1f}{:>10s}".format(
        n, mt, re_t, h_o, n * ua_t, reg))
L("")
L("  -> only n = 1 is even transitional.  Every splitting case is laminar,")
L("     where D-B does not apply at all.  The laminar annulus (r_i/r_o 0.71,")
L("     inner wall heated, Nu about 5) gives:")
L("")
NU_LAM = 5.0
for n in (2, 4, 8):
    mt = M_OIL / n
    dh = DH_O
    h_lam = NU_LAM * K_O / dh
    ua_t = ua_from(H_I_FROZEN, h_lam)
    L("     n = {:2d}: h_o {:.0f} W/m2K, UA per tube {:.1f}, total {:.1f} W/K".format(
        n, h_lam, ua_t, n * ua_t))
L("")
L("  -> in laminar h_o is Re-independent, so total UA grows only LINEARLY in")
L("     n, not as n^0.2: at n = 4 it is {:.1f} W/K, BELOW the single tube's".format(
    4.0 * ua_from(H_I_FROZEN, NU_LAM * K_O / DH_O)))
L("     {:.1f}.  Nine tubes match one; 32 reach 150.  So the honest count for".format(
    ua_from(H_I_FROZEN, h_o_db(M_OIL, GAP)[0])))
L("     150 W/K at a fixed 0.148 kg/s is about 32, not about 1e2 -- and it")
L("     only exists if the oil film is declared laminar, i.e. under a")
L("     different correlation from the one that produced the 1e2.")
L("")
L("  the LBE side is the second casualty, and it does not show:")
L("")
L("{:>4s}{:>12s}{:>10s}{:>8s}{:>16s}".format(
    "n", "m_LBE/tube", "Re_LBE", "h_i", "note"))
for n in (1, 4, 16, 32):
    mt = 0.2651 / n
    re_l = 4.0 * mt / (math.pi * D_M * mu(530.0))
    h_l = h_i_of(mt, 530.0)
    note = "frozen value" if n == 1 else ("out of domain" if re_l < 2300 else "degraded")
    L("{:4d}{:12.4f}{:10.0f}{:8.0f}{:>16s}".format(n, mt, re_l, h_l, note))
L("")
L("  -> at n = 32 the LBE flow per tube is Re {:.0f}, also outside the".format(
    4.0 * 0.2651 / 32.0 / (math.pi * D_M * mu(530.0))))
L("     Kutateladze domain.  But the form still returns h_i {:.0f}, because".format(
    h_i_of(0.2651 / 32.0, 530.0)))
L("     its Pe -> 0 asymptote is Nu = 5.9, and UA barely moves.  That is")
L("     worse than a divergence: an invalid correlation returning a")
L("     plausible number cannot be caught by looking at the output.")
L("")
L("  which makes the construction moot rather than wrong.  It exists only to")
L("  reach UA = 150, and 150 was never a requirement: 73-75 W/K is what the")
L("  loop needs, and ONE 1 m tube delivers it at 0.50 kg/s.  The tube count")
L("  never has to be chosen.  Withdrawn as irrelevant, not as conservative.")
L("")

# ==================================================== [6] freeze / retract
rule("=")
L("[6] what this round retracts, and what it freezes")
L("")
for s in (
    "W12  'the oil flow is 0.106-0.286 kg/s'.  Withdrawn.  Re 2808-7594 on",
    "     a Dittus-Boelter evaluation whose floor is 1e4.  Both ends fail,",
    "     not only the low one.  The number was a correlation artifact.",
    "W13  'a fixed total oil flow needs about 1e2 tubes for 150 W/K'.",
    "     Withdrawn.  Per-tube Re falls as 1/n; at n = 4 it is 981, laminar,",
    "     where UA grows only linearly (18 W/K, below one tube).  The honest",
    "     count for 150 is about 32 under a laminar oil film.  Moot anyway:",
    "     the requirement is 73-75 W/K, not 150.",
    "W14  'q_net is 20 pct of Q'.  Reversed.  20 pct is the loss; Q_net is",
    "     79-80 pct.  3 pct of Q_net at 4.3 kW is 102 W, not 130 W.",
    "C1   the oil side has exactly two honest options, and they must be",
    "     declared as such: (a) flow >= 0.377 kg/s so that h_o is a",
    "     measurement, with the flow-rich, small-dT, mixing-valve design",
    "     that follows; or (b) keep 0.148 kg/s, lengthen the tube to about",
    "     1.5 m (1 m of it cannot reach 473.15 K at 6 kW even fully cold),",
    "     and use a transitional correlation with a declared h_o",
    "     uncertainty, which then enters the GSA.  No third option.",
    "C2   0.377 kg/s is conditional on mu = 1.0e-3 Pa s.  The procurement",
    "     item is the oil's mu(T) over 433-473 K; the flow is linear in it.",
    "     At 2e-3 the requirement is 0.75 kg/s.",
    "C3   the 3 kW end is the pinch: at the clean design UA it needs a",
    "     6.7 K approach at the cold end.  Degradation in UA RAISES that",
    "     approach, so fouling is not the risk; a stuck-cold mixing valve",
    "     is.  The control law must be able to command 466.5 K, not just",
    "     433.15 K.",
    "C4   6 kW is closed: after aligning roughness, K_aux and loss",
    "     bookkeeping the lumped and along-path models differ by 0.18 pct.",
    "     The 3 pct was an input mismatch, and it is retired.",
):
    L("  " + s)

out = os.path.join(os.path.dirname(os.path.abspath(__file__)), "probe_v29_log.txt")
with open(out, "w", encoding="ascii", newline="\n") as f:
    f.write("\n".join(LOG) + "\n")
print("\n".join(LOG))
print("\n[log written] " + out)
