"""Rigorous interval arithmetic and the interval image of the frozen core.

Rules this module obeys
-----------------------
1. Every arithmetic operation rounds OUTWARD by one ulp
   (`math.nextafter`), so a computed interval contains the exact real result
   of the expression tree that was evaluated.
2. Every transcendental is applied only through a function proven monotone
   on the interval in question, using the two endpoints, and the result is
   widened by 4 ulp.  There is no Taylor truncation anywhere.
3. The march is written in the exact-difference form

       dT_seg = Q_seg/(m cp) * mf(a) - (1 - exp(-a)) (T - T_amb)
       mf(a)  = (1 - exp(-a))/a,        a = u L/(m cp)

   which is algebraically the same as `Teq + (T-Teq) exp(-a)` in core_v2 but
   does not cancel.  For this loop a ~ 2.5e-3: the exp form subtracts two
   numbers that agree to three digits and would inflate every interval by
   tens of percent.  The two forms are the same function.

What this module does NOT do
----------------------------
It does not remove the dependency problem.  Interval evaluation of a
straight-line program forgets the correlation between repeated variables.
That loss is MEASURED in the logs and never assumed away.

`DI` carries one first-order derivative as an interval, so the same march
yields both a value enclosure and a rigorous enclosure of a partial
derivative.  Only one direction at a time is seeded.
"""

from __future__ import annotations

import math

import numpy as np

import core_v2 as C

_INF = math.inf


def _dn(x):
    return math.nextafter(x, -_INF)


def _up(x):
    return math.nextafter(x, _INF)


def _widen(lo, hi, n=4):
    for _ in range(n):
        lo = _dn(lo)
        hi = _up(hi)
    return lo, hi


class Iv:
    """Closed real interval [lo, hi]."""

    __slots__ = ("lo", "hi")

    def __init__(self, lo, hi=None):
        if hi is None:
            hi = lo
        lo = float(lo)
        hi = float(hi)
        if not (lo <= hi):
            raise ValueError("empty interval [%r, %r]" % (lo, hi))
        self.lo = lo
        self.hi = hi

    @staticmethod
    def of(x):
        if isinstance(x, Iv):
            return x
        if isinstance(x, DI):
            return x.v
        return Iv(x)

    @property
    def mid(self):
        return 0.5 * (self.lo + self.hi)

    @property
    def width(self):
        return self.hi - self.lo

    def has_zero(self):
        return self.lo <= 0.0 <= self.hi

    def strictly_positive(self):
        return self.lo > 0.0

    def __contains__(self, x):
        return self.lo <= x <= self.hi

    def __add__(self, o):
        o = Iv.of(o)
        return Iv(_dn(self.lo + o.lo), _up(self.hi + o.hi))

    __radd__ = __add__

    def __sub__(self, o):
        o = Iv.of(o)
        return Iv(_dn(self.lo - o.hi), _up(self.hi - o.lo))

    def __rsub__(self, o):
        return Iv.of(o).__sub__(self)

    def __neg__(self):
        return Iv(-self.hi, -self.lo)

    def __mul__(self, o):
        o = Iv.of(o)
        c = (self.lo * o.lo, self.lo * o.hi, self.hi * o.lo, self.hi * o.hi)
        return Iv(_dn(min(c)), _up(max(c)))

    __rmul__ = __mul__

    def recip(self):
        if self.lo <= 0.0 <= self.hi:
            raise ZeroDivisionError("interval contains 0")
        return Iv(_dn(1.0 / self.hi), _up(1.0 / self.lo))

    def __truediv__(self, o):
        return self * Iv.of(o).recip()

    def __rtruediv__(self, o):
        return Iv.of(o).__truediv__(self)

    def sq(self):
        a, b = self.lo * self.lo, self.hi * self.hi
        if self.lo <= 0.0 <= self.hi:
            return Iv(0.0, _up(max(a, b)))
        return Iv(_dn(min(a, b)), _up(max(a, b)))

    def pow_int(self, n):
        if n < 0:
            return self.pow_int(-n).recip()
        if n == 0:
            return Iv(1.0)
        if n % 2 == 0:
            return self.sq().pow_int(n // 2)
        return self * self.sq().pow_int((n - 1) // 2)

    def __repr__(self):
        return "[%.12g, %.12g]" % (self.lo, self.hi)


class DI:
    """value Iv + one first-order derivative Iv."""

    __slots__ = ("v", "d")

    def __init__(self, v, d=None):
        self.v = Iv.of(v)
        self.d = Iv(0.0) if d is None else Iv.of(d)

    @staticmethod
    def seed(v, d=1.0):
        return DI(Iv.of(v), Iv(d))

    def __add__(self, o):
        o = o if isinstance(o, DI) else DI(o)
        return DI(self.v + o.v, self.d + o.d)

    __radd__ = __add__

    def __sub__(self, o):
        o = o if isinstance(o, DI) else DI(o)
        return DI(self.v - o.v, self.d - o.d)

    def __rsub__(self, o):
        return DI(o).__sub__(self)

    def __neg__(self):
        return DI(-self.v, -self.d)

    def __mul__(self, o):
        o = o if isinstance(o, DI) else DI(o)
        return DI(self.v * o.v, self.d * o.v + self.v * o.d)

    __rmul__ = __mul__

    def __truediv__(self, o):
        o = o if isinstance(o, DI) else DI(o)
        inv = o.v.recip()
        v = self.v * inv
        return DI(v, (self.d - v * o.d) * inv)

    def sq(self):
        return DI(self.v.sq(), self.v * self.d * 2.0)

    def __repr__(self):
        return "DI(%r, d=%r)" % (self.v, self.d)


# --------------------------------------------------- monotone scalar kernels
def _mf_scalar(a):
    """(1 - exp(-a))/a, a > 0."""
    if a <= 0.0:
        raise ValueError("a must be > 0")
    return -math.expm1(-a) / a


def _mf_der_scalar(a):
    """d mf/da = (e^-a (1+a) - 1)/a^2, proved to lie in (-1/2, 0)."""
    if a <= 0.0:
        raise ValueError("a must be > 0")
    if a < 1e-3:
        return -0.5 + a / 3.0 - a * a / 8.0 + a ** 3 / 30.0
    e = math.exp(-a)
    g = a + (e - 1.0) + a * (e - 1.0)          # (1+a) e^-a - 1 without cancellation
    return g / (a * a)


def _mean_ratio_scalar(a):
    """(T_bar - T)/dT = 1/(1-e^-a) - 1/a, proved in (1/2, 1)."""
    if a <= 0.0:
        raise ValueError("a must be > 0")
    if a < 0.5:
        return 0.5 + a / 12.0 - a ** 3 / 720.0 + a ** 5 / 30240.0
    return -1.0 / math.expm1(-a) - 1.0 / a


def _mean_ratio_der(a):
    if a <= 0.0:
        raise ValueError("a must be > 0")
    if a < 0.5:
        return 1.0 / 12.0 - 3.0 * a * a / 720.0 + 5.0 * a ** 4 / 30240.0
    e = math.exp(-a)
    w = 1.0 - e
    return -e / (w * w) + 1.0 / (a * a)


def _mfup_scalar(a):
    """(e^a - 1)/a, a > 0, strictly increasing."""
    if a <= 0.0:
        raise ValueError("a must be > 0")
    return math.expm1(a) / a


def _mfup_der(a):
    if a <= 0.0:
        raise ValueError("a must be > 0")
    return (math.exp(a) * (a - 1.0) + 1.0) / (a * a)


# Proof obligations, checked once at import: the monotonicity and range
# claims the endpoint images rely on.
for _a in (1e-6, 1e-4, 1e-3, 1e-2, 0.1, 0.3, 0.5, 1.0, 2.0):
    assert 0.5 <= _mean_ratio_scalar(_a) <= 1.0
    assert -0.5 < _mf_der_scalar(_a) < 0.0
    assert _mean_ratio_der(_a) > 0.0
    assert _mfup_der(_a) > 0.0
del _a

# mf is decreasing: check the derivative sign on a grid that covers (0, 2].
_a = 1e-6
while _a < 2.0:
    assert _mf_der_scalar(_a) < 0.0
    assert _mfup_der(_a) > 0.0
    assert _mean_ratio_der(_a) > 0.0
    _a *= 1.05
del _a


def iv_exp_neg(a):
    if not a.strictly_positive():
        raise ValueError("exp_neg needs a > 0")
    return Iv(*_widen(math.exp(-a.hi), math.exp(-a.lo)))


def iv_exp_pos(a):
    if not a.strictly_positive():
        raise ValueError("exp_pos needs a > 0")
    return Iv(*_widen(math.exp(a.lo), math.exp(a.hi)))


def iv_mf(a):
    if not a.strictly_positive():
        raise ValueError("mf needs a > 0")
    return Iv(*_widen(_mf_scalar(a.hi), _mf_scalar(a.lo)))


def iv_mfup(a):
    if not a.strictly_positive():
        raise ValueError("mfup needs a > 0")
    return Iv(*_widen(_mfup_scalar(a.lo), _mfup_scalar(a.hi)))


def iv_mean_ratio(a):
    """(T_bar-T)/dT; it INCREASES from 1/2 toward 1 as a grows."""
    if not a.strictly_positive():
        raise ValueError("mean_ratio needs a > 0")
    return Iv(*_widen(_mean_ratio_scalar(a.lo), _mean_ratio_scalar(a.hi)))


def di_exp_neg(a):
    return DI(iv_exp_neg(a.v), -iv_exp_neg(a.v) * a.d)


def di_exp_pos(a):
    return DI(iv_exp_pos(a.v), iv_exp_pos(a.v) * a.d)


def _der_iv(fn, x):
    u, v = fn(x.lo), fn(x.hi)
    return Iv(*_widen(min(u, v), max(u, v)))


def di_mf(a):
    return DI(iv_mf(a.v), _der_iv(_mf_der_scalar, a.v) * a.d)


def di_mfup(a):
    return DI(iv_mfup(a.v), _der_iv(_mfup_der, a.v) * a.d)


def di_mean_ratio(a):
    return DI(iv_mean_ratio(a.v), _der_iv(_mean_ratio_der, a.v) * a.d)


# ---------------------------------------------------------------- properties
def _cp_scalar(T):
    return 164.8 - 3.94e-2 * T + 1.25e-5 * T * T - 4.56e5 / (T * T)


def _cp_der_iv(T):
    """dcp/dT = -0.0394 + 2.5e-5 T + 9.12e5/T^3; each term monotone in T>0."""
    return Iv(-3.94e-2) + T * 2.5e-5 + T.pow_int(3).recip() * 9.12e5


T_LO = 455.0   # lower end of the declared cp/mu correlation window
T_HI = 1570.0  # upper end of the declared cp/mu window


def di_cp(T, f):
    """cp_of(T, f).  cp is strictly decreasing on [455, 1570] K (checked)."""
    Ti = T.v
    if Ti.lo < 455.0 or Ti.hi > 1570.0:
        raise ValueError("cp window violated: %r" % Ti)
    img = Iv(*_widen(_cp_scalar(Ti.hi), _cp_scalar(Ti.lo)))
    der = _cp_der_iv(Ti)
    if der.hi >= 0.0:
        raise ValueError("cp not decreasing: %r" % der)
    return DI(f.v * img, f.d * img + f.v * der * T.d)


def _mu_scalar(T):
    return 4.94e-4 * math.exp(754.1 / T)


def di_mu(T, f):
    """mu_of(T, f), strictly decreasing in T."""
    Ti = T.v
    if Ti.lo < 455.0 or Ti.hi > 1570.0:
        raise ValueError("mu window violated: %r" % Ti)
    img = Iv(*_widen(_mu_scalar(Ti.hi), _mu_scalar(Ti.lo)))
    d_lo = -754.1 * _mu_scalar(Ti.lo) / (Ti.lo * Ti.lo)
    d_hi = -754.1 * _mu_scalar(Ti.hi) / (Ti.hi * Ti.hi)
    der = Iv(*_widen(min(d_lo, d_hi), max(d_lo, d_hi)))
    return DI(f.v * img, f.d * img + f.v * der * T.d)


def di_rho(T, f):
    """rho_of(T, f) = f (11065 - 1.293 T); affine, exact under Iv ops."""
    return f * (DI(Iv(11065.0)) - T * 1.293)


# ---------------------------------------------------------------- components
def iv_churchill(re, rr):
    """Churchill f(Re, rel_rough): decreasing in Re, increasing in rr.

    Proof by composition, no derivative needed:
      inner = (7/Re)^0.9 + 0.27 rr        decreasing in Re, increasing in rr
      ln(1/inner)                          increasing in Re, decreasing in rr
      a = (2.457 ln(...))^16               increasing in Re, decreasing in rr
      b = (37530/Re)^16                    decreasing in Re
      (8/Re)^12 and (a+b)^-1.5             both decreasing in Re
      f = 8[(8/Re)^12 + (a+b)^-1.5]^(1/12) decreasing in Re
    and increasing in rr through a only.  Requires 0 < inner < 1.
    """
    if re.lo < 400.0:
        raise ValueError("churchill Re window violated: %r" % re)
    # eps is >= 0 by the box definition; an exact zero product leaves the
    # bookkeeping ulp +-5e-324 around zero, clamped back here.
    if rr.lo < -1e-300 or rr.hi > 2.5e-3:
        raise ValueError("churchill roughness window violated: %r" % rr)
    rr = Iv(max(0.0, rr.lo), rr.hi)
    if (7.0 / re.lo) ** 0.9 + 0.27 * rr.hi >= 1.0:
        raise ValueError("inner >= 1: monotonicity proof fails")
    return Iv(*_widen(C.churchill(re.hi, rr.lo), C.churchill(re.lo, rr.hi)))


def iv_elbow(re):
    if re.lo < 500.0 or re.hi > 60000.0:
        raise ValueError("elbow Re window violated: %r" % re)
    return Iv(*_widen(C.elbow_mitre(re.hi), C.elbow_mitre(re.lo)))


def iv_orifice(d_hole):
    """NEA #3, D=16 mm, t=2 mm; strictly decreasing in d_hole (checked)."""
    if d_hole.lo < 0.0095 or d_hole.hi > 0.0105:
        raise ValueError("orifice window violated: %r" % d_hole)
    return Iv(*_widen(C.orifice_nea3(0.016, d_hole.hi, 0.002),
                      C.orifice_nea3(0.016, d_hole.lo, 0.002)))


def iv_table2(re):
    """Yue Table 2 piecewise-linear K(Re): exact envelope over the breakpoints.

    No global monotonicity is asserted; the envelope is built from the two
    interval ends plus every printed breakpoint inside, which is exact for a
    continuous piecewise-linear function.
    """
    lo = max(re.lo, C.T2_LO)
    hi = min(re.hi, C.T2_HI)
    if lo > hi:
        raise ValueError("Re outside Table 2 printed range: %r" % re)
    pts = [lo, hi] + [r[0] for r in C.TABLE2 if lo < r[0] < hi]
    ks = [C.table2_k(p) for p in pts]
    return tuple(Iv(*_widen(min(k[i] for k in ks), max(k[i] for k in ks)))
                 for i in range(3))


def iv_table2_der(re):
    """dK/dRe: union of the slopes of the segments the interval touches."""
    lo = max(re.lo, C.T2_LO)
    hi = min(re.hi, C.T2_HI)
    if lo > hi:
        raise ValueError("Re outside Table 2 printed range: %r" % re)
    s = [[], [], []]
    for a, b in zip(C.TABLE2[:-1], C.TABLE2[1:]):
        if b[0] < lo or a[0] > hi:
            continue
        for i in range(3):
            s[i].append((b[i + 1] - a[i + 1]) / (b[0] - a[0]))
    return tuple(Iv(min(x), max(x)) for x in s)


# ---------------------------------------------------------------- parameters
ORDER = ("m", "qe", "T_in", "eps", "k_bend", "k_orif", "k_aux", "u_fac",
         "fmu", "fcp", "frho", "d_hole_scale", "lhs_scale")


def param_values(loop, x, qe):
    """Scalar parameters of the frozen model for one loop at one input point."""
    d = dict(zip(C.NAMES, x))
    is_m = loop["label"].startswith("M")
    return dict(
        m=None,
        qe=float(qe),
        T_in=C.T_IN_REF + (d["dTin_M"] if is_m else d["dTin_P"]),
        eps=(d["eps_M"] * 1e-6 if is_m else 0.0),
        k_bend=1.0,
        k_orif=1.0,
        k_aux=(d["k_aux_M"] if is_m else 0.0),
        u_fac=d["u_loss_fac"],
        fmu=d["mu_fac"],
        fcp=d["cp_fac"],
        frho=d["rho_fac"],
        d_hole_scale=(d["d_hole"] / 10.0 if is_m else 1.0),
        lhs_scale=(d["L_HS_M"] if is_m else 1.0),
    )


def build_args(loop, x, qe, m_val, seed=None, seed_iv=None):
    """DI arguments.  `seed` names the single direction that gets d=1.

    When `seed_iv` is given it replaces the seeded value by an interval,
    which is how the sign test evaluates Phi over a box at a fixed flow.
    """
    p = param_values(loop, x, qe)
    p["m"] = m_val
    out = {}
    for k in ORDER:
        if k == seed:
            v = Iv(p[k]) if seed_iv is None else seed_iv
            out[k] = DI.seed(v)
        else:
            out[k] = DI(Iv(p[k]))
    return out


def box_args(loop, q_lo, q_hi, m_val, cell=None, m_iv=None):
    """Interval parameters covering the declared box, or one sub-cell of it.

    `cell` maps an axis name to its (lo, hi) over the cell; every axis not
    named keeps its full declared range.  `m_val` is a point flow, which is
    what the sign test needs: Phi is evaluated at one flow over a whole box.
    `m_iv` replaces that point by a flow interval, which is what the finite
    cover of a monotonicity claim needs: one slab of the bracket at a time.
    """
    is_m = loop["label"].startswith("M")
    B = {n: list(b) for n, b in zip(C.NAMES, C.BOUNDS)}
    for k, (lo, hi) in (cell or {}).items():
        B[k] = [lo, hi]
    ax = "M" if is_m else "P"
    pick = lambda n: B[n] if (is_m or C.INPUTS[C.IDX[n]][1] == "both") else [0.0, 0.0]
    eps = B["eps_M"] if is_m else [0.0, 0.0]
    dh = B["d_hole"] if is_m else [10.0, 10.0]
    lhs = B["L_HS_M"] if is_m else [1.0, 1.0]
    kaux = B["k_aux_M"] if is_m else [0.0, 0.0]
    dtin = B["dTin_" + ax]
    return dict(
        m=DI(Iv(*(m_iv if m_iv is not None else (m_val,)))),
        qe=DI(Iv(q_lo, q_hi)),
        T_in=DI(Iv(C.T_IN_REF + dtin[0], C.T_IN_REF + dtin[1])),
        eps=DI(Iv(eps[0] * 1e-6, eps[1] * 1e-6)),
        k_bend=DI(Iv(1.0)),
        k_orif=DI(Iv(1.0)),
        k_aux=DI(Iv(*kaux)),
        u_fac=DI(Iv(*B["u_loss_fac"])),
        fmu=DI(Iv(*B["mu_fac"])),
        fcp=DI(Iv(*B["cp_fac"])),
        frho=DI(Iv(*B["rho_fac"])),
        d_hole_scale=DI(Iv(dh[0] / 10.0, dh[1] / 10.0)),
        lhs_scale=DI(Iv(*lhs)),
    )


# ------------------------------------------------- dual component images
def di_pow_pos(x, p):
    """x^p for x > 0 and real p; monotone, so the image is exact."""
    xv = x.v
    if xv.lo <= 0.0:
        raise ValueError("pow needs x > 0: %r" % xv)
    lo, hi = xv.lo ** p, xv.hi ** p
    if p < 0.0:
        lo, hi = hi, lo
    q = p - 1.0
    l2, h2 = xv.lo ** q, xv.hi ** q
    if q < 0.0:
        l2, h2 = h2, l2
    return DI(Iv(*_widen(lo, hi)), Iv(*_widen(l2, h2)) * p * x.d)


def di_ln(x):
    xv = x.v
    if xv.lo <= 0.0:
        raise ValueError("ln needs x > 0: %r" % xv)
    return DI(Iv(*_widen(math.log(xv.lo), math.log(xv.hi))),
              xv.recip() * x.d)


def di_churchill(Re, rr):
    """Churchill f(Re, rel_rough), factored so the derivative stays tight.

    The textbook form is
        f = 8 S^(1/12),  S = (8/Re)^12 + (a+b)^(-1.5),  a = L^16
    with L = 2.457 ln(1/inner), b = (37530/Re)^16.  Differentiating that
    chain carries a relative width of 16x on `a`, which makes df/dm straddle
    zero over a wide box even though f is monotone.  The algebraically
    identical factorization

        S = L^-24 (T1 + T2),   T1 = (8/Re)^12 L^24,   T2 = (1 + b L^-16)^-1.5
        f = 8 L^-2 (T1 + T2)^(1/12)

    keeps every intermediate small: T1 <= 5e-5 in this Re window, so
    (T1+T2) is 1 to 1e-4 and the whole sensitivity sits in L^-2, whose
    relative width is only 2x that of L.
    """
    inner = di_pow_pos(DI(Iv(7.0)) / Re, 0.9) + rr * 0.27
    if inner.v.hi >= 1.0 or inner.v.lo <= 0.0:
        raise ValueError("churchill: inner outside (0,1)")
    L = di_ln(DI(Iv(1.0)) / inner) * 2.457
    b = di_pow_pos(DI(Iv(37530.0)) / Re, 16.0)
    T1 = di_pow_pos(DI(Iv(8.0)) / Re, 12.0) * di_pow_pos(L, 24.0)
    T2 = di_pow_pos(DI(Iv(1.0)) + b * di_pow_pos(L, -16.0), -1.5)
    return di_pow_pos(L, -2.0) * di_pow_pos(T1 + T2, 1.0 / 12.0) * 8.0


def di_elbow(Re):
    return di_pow_pos(Re, -0.77) * 427.5 + 0.9


def di_orifice(d_hole):
    """NEA #3, D = 16 mm, t = 2 mm; exact derivative in d_hole."""
    Dm, t = 0.016, 0.002
    beta = di_pow_pos(d_hole / Dm, 2.0)
    c = DI(Iv(1.0)) - beta
    ell = t / Dm
    inv = ell ** -8
    phi = 0.25 + 0.535 * inv / (0.05 + inv)
    tau = (2.4 - ell) * 10.0 ** (-phi)
    N = c * 0.5 + c.sq() + di_pow_pos(c, 1.5) * tau
    Dn = beta.sq()
    # dK/dbeta (N' Dn - N Dn') / Dn^2, all factors positive
    dN = DI(Iv(-0.5)) + c * (-2.0) + di_pow_pos(c, 0.5) * (-1.5 * tau)
    dDn = beta * 2.0
    dKdb = (dN * Dn - N * dDn) / Dn.sq()
    return N / Dn, dKdb


def iv_table2_total(re):
    """K_total(Re) with the constant clamp outside the printed range.

    The clamp is the extension core_v2.solve uses while bracketing, so the
    enclosure below belongs to the same extended function the solver uses.
    """
    if re.hi < C.T2_LO:
        k = C.table2_total(C.T2_LO)
        return Iv(*_widen(k, k))
    if re.lo > C.T2_HI:
        k = C.table2_total(C.T2_HI)
        return Iv(*_widen(k, k))
    lo = max(re.lo, C.T2_LO)
    hi = min(re.hi, C.T2_HI)
    pts = [lo, hi] + [r[0] for r in C.TABLE2 if lo < r[0] < hi]
    ks = [C.table2_total(p) for p in pts]
    return Iv(*_widen(min(ks), max(ks)))


def iv_table2_total_der(re):
    """Slope of K_total(Re): union of the touched segment slopes, plus 0 in
    the clamped regions."""
    sl = []
    if re.lo < C.T2_LO or re.hi > C.T2_HI:
        sl.append(0.0)          # clamped extension: K is constant there
    if re.hi >= C.T2_LO and re.lo <= C.T2_HI:
        lo = max(re.lo, C.T2_LO)
        hi = min(re.hi, C.T2_HI)
        for a, b in zip(C.TABLE2[:-1], C.TABLE2[1:]):
            if b[0] < lo or a[0] > hi:
                continue
            sl.append(sum(b[i + 1] - a[i + 1] for i in range(3))
                      / (b[0] - a[0]))
    if not sl:
        sl = [0.0]
    return Iv(*_widen(min(sl), max(sl)))


def di_table2_total(re):
    return DI(iv_table2_total(re.v), iv_table2_total_der(re.v) * re.d)


# axis name -> (parameter key, d(parameter)/d(axis))
AXIS_MAP = {
    "eps_M": ("eps", 1e-6),
    "d_hole": ("d_hole_scale", 0.1),
    "k_aux_M": ("k_aux", 1.0),
    "u_loss_fac": ("u_fac", 1.0),
    "mu_fac": ("fmu", 1.0),
    "cp_fac": ("fcp", 1.0),
    "rho_fac": ("frho", 1.0),
    "dTin_P": ("T_in", 1.0),
    "dTin_M": ("T_in", 1.0),
    "L_HS_M": ("lhs_scale", 1.0),
    "Qe": ("qe", 1.0),
    "m": ("m", 1.0),
}


def box_args_seeded(loop, q_lo, q_hi, m_val, axis, cell=None, m_iv=None):
    """Same as box_args but the named axis carries d/daxis (interval seed).

    The seed is scaled by d(parameter)/d(axis) so the derivative that comes
    back is with respect to the axis as declared in core_v2.INPUTS.
    `m_iv` is passed through, so a slab of the flow bracket can be seeded on
    any axis, including on the flow itself (`axis="m"`).
    """
    a = box_args(loop, q_lo, q_hi, m_val, cell, m_iv)
    key, sc = AXIS_MAP[axis]
    old = a[key]
    a[key] = DI.seed(old.v, sc)
    return a


# ---------------------------------------------------------------- the march
def march(loop, m, qe, T_in, eps, k_bend, k_orif, k_aux, u_fac, fmu, fcp, frho,
          d_hole_scale, lhs_scale, want_detail=False):
    """Interval/dual image of core_v2.march.

    Structural branches (cooler position, lumped vs distributed, P vs M) come
    from the loop spec, never from an interval comparison, so the evaluated
    expression tree is fixed and the enclosure argument is valid.
    """
    T_amb = DI(Iv(C.T_AMB))
    segs = loop["segs"]
    ic = next(i for i, s in enumerate(segs) if s["cool"])

    # ---- forward: heater and hot leg -------------------------------
    T = T_in
    means = [None] * len(segs)
    T_hs = None
    for i in range(ic):
        s = segs[i]
        sL = s["L"] * (lhs_scale if i == 0 else 1.0)
        qseg = qe * s["qfrac"]
        u = s["u"] * u_fac
        cpl = di_cp(T, fcp)
        a = u * sL / (m * cpl)
        mf = di_mf(a)
        mr = di_mean_ratio(a)
        dt = qseg / (m * cpl) * mf - (DI(Iv(1.0)) - di_exp_neg(a)) * (T - T_amb)
        means[i] = T + dt * mr
        T = T + dt
        if s["qfrac"] > 0.0 and T_hs is None:
            T_hs = T
    T_ci = T

    # ---- backward: cold leg, marched upstream from the heater inlet --
    T = T_in
    for i in range(len(segs) - 1, ic, -1):
        s = segs[i]
        u = s["u"] * u_fac
        cpl = di_cp(T, fcp)
        a = u * s["L"] / (m * cpl)
        if s["u"] > 0.0:
            rise = di_exp_pos(a) - DI(Iv(1.0))       # e^a - 1
            mr = di_mfup(a) - DI(Iv(1.0))            # (e^a-1)/a - 1
            means[i] = T + (T - T_amb) * mr
            T = T + (T - T_amb) * rise
        else:
            means[i] = T
    T_co = T

    cpm = di_cp((T_ci + T_co) * 0.5, fcp)
    means[ic] = (T_ci + T_co) * 0.5

    # ---- buoyancy ---------------------------------------------------
    # rho = frho (11065 - 1.293 T) is affine, so the loop integral is
    #   sum rho dz = frho [11065 sum(dz) - 1.293 sum(T dz)]
    # Accumulating the T-sums first and applying frho once is algebraically
    # identical and avoids the 1e2 cancellation that plain interval
    # accumulation suffers (ten terms of order 5e3 K m whose signed sum is
    # order 1e2 K m).
    sdz = 0.0
    accT = DI(Iv(0.0))
    for i, s in enumerate(segs):
        sdz += s["dz"]
        if s["dz"] != 0.0:
            accT = accT + means[i] * s["dz"]
    drho = frho * (DI(Iv(11065.0)) * sdz - accT * 1.293)
    dp_buoy = drho * (-C.G)

    # ---- friction ---------------------------------------------------
    dpf = DI(Iv(0.0))
    qloss = DI(Iv(0.0))
    k_brk = {}
    re_seg = []
    for i, s in enumerate(segs):
        Tm = means[i]
        r = di_rho(Tm, frho)
        mu = di_mu(Tm, fmu)
        per = s["per"]
        Re = m * 4.0 / (per * mu)
        re_seg.append(Re.v)
        if s["u"] > 0.0:
            qloss = qloss + u_fac * s["u"] * s["L"] * (Tm - T_amb)
        if s["cool"]:
            continue
        if loop["lumped"]:
            continue
        rr = DI(Iv(max(0.0, eps.v.lo), max(0.0, eps.v.hi)), eps.d) / s["Dh"]
        f = di_churchill(Re, rr)
        kf = f * (s["L"] / s["Dh"])
        kterm = kf + s["kown"] * k_bend.v
        # rho v^2/2 = m^2/(2 rho A^2): same number, no rho*(1/rho)^2 detour
        qdyn = m.sq() * (0.5 / (s["A"] * s["A"])) / r
        dpf = dpf + kterm * qdyn
        k_brk["pipe"] = k_brk.get("pipe", Iv(0.0)) + kf
        k_brk["bend"] = k_brk.get("bend", Iv(0.0)) + s["kown"] * k_bend.v

    n = len(means)
    mean_all = DI(Iv(0.0))
    for Tm in means:
        mean_all = mean_all + Tm
    mean_all = mean_all / n

    r_mean = di_rho(mean_all, frho)
    q_main = m.sq() * (0.5 / (loop["A_main"] * loop["A_main"])) / r_mean
    re_main = m * 4.0 / (math.pi * loop["D_main"] * di_mu(mean_all, fmu))

    if loop["n_elbow"]:
        kb = di_elbow(re_main) * (loop["n_elbow"] * k_bend.v)
        dpf = dpf + kb * q_main
        k_brk["bend"] = k_brk.get("bend", Iv(0.0)) + kb

    if loop["label"].startswith("M"):
        d_h = d_hole_scale * 0.010
        ko, dkdb = di_orifice(d_h)
        ko = ko * k_orif.v
        dpf = dpf + ko * q_main
        dpf = dpf + k_aux * q_main
        k_brk["orifice"] = ko.v
        k_brk["aux"] = k_aux.v
    else:
        mode = loop.get("k_p_mode", "table2")
        if mode == "table2":
            ktot = di_table2_total(re_main)
        elif mode == "frozen":
            ktot = DI(Iv(24.8))
        elif mode == "churchill":
            r0 = 4.0 * 1.25 / (math.pi * loop["D_main"] * _mu_scalar(mean_all.v.mid))
            ktot = di_churchill(re_main, DI(Iv(0.0))) * (17.7 / C.churchill(r0)) \
                + DI(Iv(5.1))
        else:
            raise ValueError(mode)
        dpf = dpf + ktot * q_main
        k_brk["total_k"] = ktot.v

    out = dict(dp_buoy=dp_buoy, dp_fric=dpf, qloss=qloss, t_hs=T_hs,
               t_ci=T_ci, t_co=T_co, re_main=re_main, k_brk=k_brk)
    if want_detail:
        out["means"] = means
        out["re_seg"] = re_seg
    return out


def phi(loop, **kw):
    """Phi = buoyancy head - friction loss, as a DI."""
    r = march(loop, **kw)
    return r["dp_buoy"] - r["dp_fric"], r
