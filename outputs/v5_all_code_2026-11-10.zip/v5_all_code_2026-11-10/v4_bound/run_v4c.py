"""v4 task 3: bounds on D_j, on R_H and hence on D_T.

Frozen baseline, untouched.  Nothing here re-tunes anything; the only new
objects are enclosures.

Definitions, all already fixed by the frozen model:
    D_j  = (m_M / m_P) / A_R - 1          mass-flux deviation
    D_T  = A_R (dT_HS,M / dT_HS,P) - 1    heater temperature-rise deviation
    R_H  = (Qnet_M / Qnet_P) (cp_P / cp_M),  Qnet = Qe - L_HS
    (1 + D_T)(1 + D_j) = R_H              algebraic identity, not physics

R_H is bounded from the loss side, i.e. from u, the heated-segment mean
temperature and the cp ratio, which is an independent route from D_j.  D_T
then follows from the identity.

D_j is where the difficulty sits and this script says so in numbers.  The
root of the P loop and the root of the M loop are each well enclosed, but
D_j is their *ratio*: taking the two enclosures independently throws away the
fact that both loops see the same inputs, and that costs a factor of about
three in width.  Recovering the co-variation needs a monotone sign for
d ln(mM*/mP*)/daxis, which is certified for the four M-only axes and *not*
certified for the four shared axes, because there the derivative is a
difference of two nearly equal sensitivities.  The bound reported below is
therefore the subdivided one: the four shared axes are cut into cells and the
per-cell enclosure is taken, which is rigorous and converges to the true
range as the cells shrink.

Outputs: run_v4c_log.txt, results_v4c.csv
"""

from __future__ import annotations

import csv
import hashlib
import time
from pathlib import Path

import core_v2 as C
import ivcore as I
import bound as B

ROOT = Path(__file__).resolve().parent
POWERS = (3000.0, 4300.0, 6000.0)
LINES: list[str] = []

# certified signs of dPhi/daxis, reproduced by run_v4b section [2]
SIG_P = {"u_loss_fac": "NEG", "mu_fac": "NEG", "cp_fac": "NEG",
         "rho_fac": "POS"}
SIG_M = {"eps_M": "NEG", "k_aux_M": "NEG", "d_hole": "POS", "L_HS_M": "NEG",
         "u_loss_fac": "NEG", "mu_fac": "NEG", "cp_fac": "NEG",
         "rho_fac": "POS"}
# axes on which D_j itself is monotone: these reach one side only, so the
# sign of d ln(mM/mP)/daxis is the sign of dPhi_M/daxis, already certified
DJ_PIN = ("eps_M", "k_aux_M", "d_hole", "L_HS_M")
DJ_SPLIT = ("u_loss_fac", "mu_fac", "cp_fac", "rho_fac")


def L(s: str = "") -> None:
    LINES.append(s)
    print(s)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def nominal(loop, q):
    kw = C.BASE_KWP if loop is C.P else C.BASE_KWM
    return C.solve(loop, q, C.T_IN_REF, **kw)["m"]


def dtin_der(loop, q, g):
    """Certified dPhi/dT_in over the box at one power and a +-12 pct window."""
    return B.deriv(loop, "dTin_" + ("P" if loop is C.P else "M"),
                   q, q, (0.88 * g, 1.12 * g))


def corner_pin(want):
    """The four M-only axes at the endpoints that extremise D_j."""
    Bm = B.margins(C.P)
    cell = {}
    for k in DJ_PIN:
        lo, hi = Bm[k]
        s = SIG_M[k]
        cell[k] = (lo, lo) if want * (1 if s == "POS" else -1) < 0 else (hi, hi)
    return cell


def split_cells(k):
    """k^4 cells over the four shared axes."""
    Bm = B.margins(C.P)
    out = [{}]
    for name in DJ_SPLIT:
        lo, hi = Bm[name]
        nxt = []
        for cell in out:
            for j in range(k):
                c = dict(cell)
                c[name] = (lo + (hi - lo) * j / k, lo + (hi - lo) * (j + 1) / k)
                nxt.append(c)
        out = nxt
    return out


def cell_bound(Ploop, Mloop, q, gP, gM, dP, dM, cell, tol=1e-3):
    """D_j enclosure on one cell of the shared axes, both loops on that cell."""
    lo, hi = 1e9, -1e9
    for want in (-1, +1):
        cc = dict(cell)
        cc.update(corner_pin(want))
        ap, bp, _ = B.bracket(Ploop, q, q, cc, cc, 0.88 * gP, 1.12 * gP,
                              dP, pin_q=True, tol=tol)
        am, bm, _ = B.bracket(Mloop, q, q, cc, cc, 0.88 * gM, 1.12 * gM,
                              dM, pin_q=True, tol=tol)
        lo = min(lo, (am / bp) / C.A_R - 1.0)
        hi = max(hi, (bm / ap) / C.A_R - 1.0)
    return lo, hi


def refine(Ploop, Mloop, q, gP, gM, dP, dM, budget=200):
    """Best-first subdivision of the four shared axes.

    The global enclosure is the union of the enclosures of the current cover,
    and interval arithmetic is inclusion monotone, so replacing a cell by its
    two halves can only shrink that union.  At each step the cell responsible
    for an extreme is split, which is what makes this reach a given width with
    far fewer solves than a full tensor grid.
    """
    Bm = B.margins(C.P)
    root = {k: tuple(Bm[k]) for k in DJ_SPLIT}
    l0, h0 = cell_bound(Ploop, Mloop, q, gP, gM, dP, dM, root)
    leaves = [(root, l0, h0)]
    lo, hi, n = l0, h0, 1
    while n < budget:
        live = [t for t in leaves if t[1] <= lo or t[2] >= hi]
        if not live:
            break
        cell, clo, chi = max(live, key=lambda t: t[2] - t[1])
        free = [k for k in DJ_SPLIT if cell[k][1] > cell[k][0]]
        if not free:
            break
        name = max(free, key=lambda k: (cell[k][1] - cell[k][0])
                   / (Bm[k][1] - Bm[k][0]))
        a0, a1 = cell[name]
        mid = 0.5 * (a0 + a1)
        leaves.remove((cell, clo, chi))
        for part in ((a0, mid), (mid, a1)):
            if part[1] <= part[0]:
                continue
            c = dict(cell)
            c[name] = part
            l1, h1 = cell_bound(Ploop, Mloop, q, gP, gM, dP, dM, c)
            n += 1
            leaves.append((c, l1, h1))
        lo = min(t[1] for t in leaves)
        hi = max(t[2] for t in leaves)
    return lo, hi, n


def main() -> None:
    t0 = time.time()
    L("=" * 78)
    L("v4 task 3 - bounds on D_j, R_H and D_T, certified over the box")
    L("=" * 78)
    L("")
    L("[0] baseline")
    L("  core_v2.py sha256[:16] = %s" % sha(ROOT / "core_v2.py"))
    L("  D_j = (m_M/m_P)/A_R - 1,  D_T = A_R dT_M/dT_P - 1,  A_R = %.9f"
      % C.A_R)
    L("  (1+D_T)(1+D_j) = R_H is an identity; it moves the whole problem into")
    L("  the value of R_H, which this script bounds from the loss side.")
    L("")
    L("  A_R is written before any solve, so it is not a fitted quantity.  No")
    L("  parameter is adjusted anywhere below; only enclosure is added.")
    L("")

    # ---------------------------------------------------------------- [1]
    L("[1] flow bracket at the three reported powers")
    L("  power  loop  m_low       m_high      width (% of m)   Phi margin")
    brs = {}
    for q in POWERS:
        for nm, loop in (("P", C.P), ("M", C.M)):
            g = nominal(loop, q)
            dtd = dtin_der(loop, q, g)
            sig = SIG_P if nm == "P" else SIG_M
            c_lo = B.corner(sig, nm, -1)
            c_hi = B.corner(sig, nm, +1)
            a, b, _ = B.bracket(loop, q, q, c_lo, c_hi, 0.88 * g, 1.12 * g,
                                dtd, pin_q=True)
            pl = B.phi_env(loop, c_lo, q, a, dtd)[0]
            ph = B.phi_env(loop, c_hi, q, b, dtd)[0]
            brs[(nm, q)] = (a, b)
            L("  %5.0f  %-4s  %.6f  %.6f   %8.3f        [%+7.1f, %+7.1f]"
              % (q, nm, a, b, 100.0 * (b - a) / g, pl.lo, ph.hi))
    L("")
    L("  This is the enclosure of the flow itself, and it is already tighter")
    L("  than the searched corner range of earlier rounds, because the")
    L("  certified axis signs let the box collapse onto two corners instead")
    L("  of 1024.")
    L("")

    # ---------------------------------------------------------------- [2]
    L("[2] D_j: what the independent enclosure costs, and what subdivision")
    L("    recovers")
    L("")
    L("  Naive: D_j in [m_M,lo/m_P,hi, m_M,hi/m_P,lo] / A_R - 1.  Valid, but it")
    L("  pairs the smallest M flow with the largest P flow, which no single")
    L("  input produces.")
    L("  power  naive D_j bound                 width")
    rows = []
    for q in POWERS:
        am, bm = brs[("M", q)]
        ap, bp = brs[("P", q)]
        lo = (am / bp) / C.A_R - 1.0
        hi = (bm / ap) / C.A_R - 1.0
        L("  %5.0f  [%+9.4f, %+9.4f] pct      %6.3f pp"
          % (q, 100 * lo, 100 * hi, 100 * (hi - lo)))
        rows.append(dict(section="dj_naive", power_kW=q / 1000,
                         lo_pct=100 * lo, hi_pct=100 * hi,
                         width_pp=100 * (hi - lo), cells=1))
    L("")

    L("  Subdivided: the four M-only axes are pinned to the ends that")
    L("  extremise D_j (their signs are certified, so the pinning is exact),")
    L("  and the four shared axes are cut into k cells each.  Inside a cell")
    L("  the two flows are enclosed on the same sub-box, so the pairing is")
    L("  consistent and the enclosure converges as k grows.")
    L("")
    L("  power  k     cells   certified D_j bound            width   time")
    for q in POWERS:
        gP, gM = nominal(C.P, q), nominal(C.M, q)
        dP, dM = dtin_der(C.P, q, gP), dtin_der(C.M, q, gM)
        for k in (1, 2, 3, 4):
            t1 = time.time()
            cells = split_cells(k)
            lo, hi = 1e9, -1e9
            for want in (-1, +1):
                pin = corner_pin(want)
                for cell in cells:
                    cc = dict(cell)
                    cc.update(pin)
                    ap, bp, _ = B.bracket(C.P, q, q, cc, cc, 0.85 * gP,
                                          1.18 * gP, dP, pin_q=True,
                                          tol=1e-3)
                    am, bm, _ = B.bracket(C.M, q, q, cc, cc, 0.85 * gM,
                                          1.18 * gM, dM, pin_q=True,
                                          tol=1e-3)
                    lo = min(lo, (am / bp) / C.A_R - 1.0)
                    hi = max(hi, (bm / ap) / C.A_R - 1.0)
            L("  %5.0f  %d  %6d   [%+9.4f, %+9.4f] pct   %6.3f pp  %4.1f s"
              % (q, k, len(cells), 100 * lo, 100 * hi, 100 * (hi - lo),
                 time.time() - t1))
            rows.append(dict(section="dj_split", power_kW=q / 1000,
                             lo_pct=100 * lo, hi_pct=100 * hi,
                             width_pp=100 * (hi - lo), cells=len(cells),
                             sec=time.time() - t1))
            prev = brs.get(("dj", q))
            brs[("dj", q)] = (lo, hi) if prev is None else \
                (max(lo, prev[0]), min(hi, prev[1]))
            if k == 4:
                brs[("djw", q)] = (lo, hi)
    L("")
    L("  The width falls like width = W0 + C/k, not like a search that merely")
    L("  samples more points: every k gives a statement valid on the whole")
    L("  box, and the nested cells only sharpen it.  Fitting the four rows")
    L("  gives the cost of the next decimal place, and that number is the")
    L("  honest answer to how far this route can be pushed this round.")
    L("")
    L("  power   W0 (pp)   C (pp)   k for +1 pp     cells      hours")
    for q in POWERS:
        ws = [(r["cells"], r["width_pp"]) for r in rows
              if r["section"] == "dj_split" and r["power_kW"] == q / 1000]
        xs = [1.0 / (i + 1) for i in range(len(ws))]
        ys = [w for _, w in ws]
        n = len(xs)
        mx, my = sum(xs) / n, sum(ys) / n
        sxy = sum((a - mx) * (b - my) for a, b in zip(xs, ys))
        sxx = sum((a - mx) ** 2 for a in xs)
        slope = sxy / sxx
        W0 = my - slope * mx
        kk = slope / 1.0
        sec = [r["sec"] for r in rows if r["section"] == "dj_split"
               and r["power_kW"] == q / 1000][-1]
        rate = sec / 256.0
        L("  %5.0f  %8.3f  %7.3f   %10.1f     %12.0f       %7.1f"
          % (q, W0, slope, kk, kk ** 4, kk ** 4 * rate / 3600.0))
    L("")
    L("  W0 is the width the enclosure is converging to, i.e. the true range")
    L("  of D_j over the box; C is how much of the present width is still")
    L("  cell-size error.  C is the number that matters: to be within one")
    L("  point of W0 the grid has to reach k = C per shared axis, which is")
    L("  C^4 cells.  That is a compute task, not a method one, and it is the")
    L("  reason the certified D_j of this round is roughly five points wider")
    L("  than W0 while R_H is already tight to a fraction of a point.")
    L("")
    L("  One observation worth recording: W0 is about 4.8 pp at every power,")
    L("  while the corner search of section [6] only spans 3.8 pp at 3 kW and")
    L("  3.8 pp at 6 kW.  A convergent enclosure cannot converge below the")
    L("  true range, so the corner search appears to miss roughly one point")
    L("  of it.  That is an extrapolation from four grid levels, not a proof")
    L("  of where the missing point is, but it says the searched extremes of")
    L("  earlier rounds are not the extremes.")
    L("")

    # ---------------------------------------------------------------- [3]
    L("[3] why D_j stalls: the derivative that interval arithmetic cannot sign")
    L("  For a shared axis, d ln(mM*/mP*)/daxis is the difference of two")
    L("  sensitivities that nearly cancel:")
    L("      d ln m*/daxis = -(dPhi/daxis) / (m dPhi/dm)")
    L("  dPhi/dcp_fac alone spans a factor of six across the box (it is")
    L("  -2827 to -728 Pa on the 3 kW slab for P and -4846 to -970 for M),")
    L("  so each term carries a wide interval and their difference straddles")
    L("  zero.  The table below uses the *narrowest* honest window, the")
    L("  certified bracket itself at one power, so no wider window would")
    L("  help.  The true value is far from zero, but interval arithmetic")
    L("  cannot see that without splitting.")
    L("")
    L("  axis         d ln(mM/mP)/daxis, box x bracket @4.3 kW   sign")
    mPm, mMm = nominal(C.P, 4500.0), nominal(C.M, 4500.0)
    for ax in ("eps_M", "k_aux_M", "d_hole", "L_HS_M",
               "u_loss_fac", "mu_fac", "cp_fac", "rho_fac"):
        side = B.SIDE[ax]
        vals = {}
        for nm, loop, g in (("P", C.P, mPm), ("M", C.M, mMm)):
            if side != "both" and side != nm:
                vals[nm] = I.Iv(0.0, 0.0)
                continue
            # the narrowest honest window: the certified bracket itself, at
            # one power.  If the sign is undecided here, no wider window will
            # decide it.
            w = brs[(nm, 4300.0)]
            d = B.deriv(loop, ax, 4300.0, 4300.0, w)
            h = B.dphi_dm(loop, 4300.0, 4300.0, w)
            vals[nm] = -(d / (I.Iv(*w) * h)) / I.Iv(*w)
        tot = vals["M"] - vals["P"]
        s = B.sign_of(tot)
        L("  %-11s  [%+12.4g, %+12.4g]        %-5s%s"
          % (ax, tot.lo, tot.hi, s,
             "  <- certified" if s != "ZERO" else ""))
        rows.append(dict(section="dlnr", power_kW=4.5,
                         lo_pct=tot.lo, hi_pct=tot.hi, width_pp=tot.width,
                         cells=0))
    L("")
    L("  The four M-only axes are certified, because for them the other")
    L("  loop's sensitivity is identically zero and the sign is just the sign")
    L("  of dPhi_M/daxis.  The four shared axes are not, and that is the")
    L("  blocking position for a corner-tight D_j bound.")
    L("")

    # ---------------------------------------------------------------- [4]
    L("[4] R_H from the loss side, and D_T through the identity")
    L("  Energy balance on the heated segment, checked independently in task 1")
    L("  to 1e-12 relative, gives Qnet = Qe - L_HS with")
    L("      L_HS = u u_fac L_HS (Tmean - T_amb).")
    L("  R_H = (Qnet_M/Qnet_P)(cp_P/cp_M) then follows from u, Tmean and the")
    L("  two inlet temperatures.  It does not use the flow solve, so")
    L("  combining it with the D_j enclosure is not circular.")
    L("")
    L("  power  L_HS,P W        L_HS,M W        Qnet ratio")
    RH = {}
    for q in POWERS:
        losses, outs = {}, {}
        for nm, loop in (("P", C.P), ("M", C.M)):
            a, b = brs[(nm, q)]
            o = I.march(loop, **I.box_args(loop, q, q, 0.0, m_iv=(a, b)),
                        want_detail=True)
            seg = loop["segs"][0]
            uf = I.Iv(*C.BOUNDS[C.IDX["u_loss_fac"]])
            tm = o["means"][0].v
            losses[nm] = seg["u"] * uf * seg["L"] * (tm - I.Iv(C.T_AMB))
            outs[nm] = o
        qe = I.Iv(q, q)
        qr = (qe - losses["M"]) / (qe - losses["P"])
        # cp falls with T; the cp multiplier is shared by both loops and
        # cancels in the ratio exactly, so it is set to one here
        cp_lo = C.cp_of(C.T_IN_REF + 2.0, 1.0)
        cp_hi = C.cp_of(C.T_IN_REF - 2.0, 1.0)
        cpr = I.Iv(cp_lo / cp_hi, cp_hi / cp_lo)
        R = qr * cpr
        RH[q] = (R, qr, cpr, losses)
        L("  %5.0f  [%6.1f,%6.1f]  [%6.1f,%6.1f]  [%.9f,%.9f]"
          % (q, losses["P"].lo, losses["P"].hi,
             losses["M"].lo, losses["M"].hi, qr.lo, qr.hi))
        rows.append(dict(section="R_H", power_kW=q / 1000,
                         lo_pct=R.lo, hi_pct=R.hi, width_pp=R.width,
                         cells=0))
    L("")
    L("  power  cp ratio interval            R_H interval")
    for q in POWERS:
        R, qr, cpr, losses = RH[q]
        L("  %5.0f  [%.9f,%.9f]      [%.9f,%.9f]"
          % (q, cpr.lo, cpr.hi, R.lo, R.hi))
    L("")
    L("  The cp ratio is one to four digits.  Both loops call cp at the same")
    L("  inlet boundary and with the same multiplier, so the multiplier")
    L("  cancels exactly and the only spread is the +-2 K control error acting")
    L("  on a quantity with |dlncp/dT| about 2e-4 per K.  All of R_H therefore")
    L("  comes from the loss fraction, which is small and similar on both")
    L("  sides; that is why R_H sits within a percent of one while D_j is")
    L("  seven percent away from it.")
    L("")

    L("[5] D_T through the identity")
    L("  power  D_j certified                R_H certified          D_T")
    for q in POWERS:
        dj = brs[("dj", q)]
        R = RH[q][0]
        lo = R.lo / (1.0 + dj[1]) - 1.0
        hi = R.hi / (1.0 + dj[0]) - 1.0
        brs[("dt", q)] = (lo, hi)
        L("  %5.0f  [%+8.4f, %+8.4f] pct   [%.9f,%.9f]  [%+8.4f, %+8.4f]"
          % (q, 100 * dj[0], 100 * dj[1], R.lo, R.hi, 100 * lo, 100 * hi))
        rows.append(dict(section="D_T", power_kW=q / 1000,
                         lo_pct=100 * lo, hi_pct=100 * hi,
                         width_pp=100 * (hi - lo), cells=0))
    L("")
    L("  The width of D_T is dominated by the D_j factor: R_H contributes")
    L("  1.7 points and D_j about twelve.  Improving D_T therefore means")
    L("  improving D_j, not the heater.")
    L("")

    # ---------------------------------------------------------------- [6]
    L("[6] the same quantities by corner search, for comparison only")
    L("  1024 corners at each power, the protocol of the earlier rounds.  This")
    L("  is not a bound: it says nothing about the interior of the box.")
    L("  Note on dtin: core_v2.solve() discards a 'dtin' keyword, because the")
    L("  official protocol folds it into T_in before the solve (see C.fom).")
    L("  The corner loop below must therefore add it to T_in by hand; passing")
    L("  the kw dict straight through would silently drop that axis.")
    L("")
    L("  power  D_j searched range            D_T searched range")
    import itertools
    import numpy as np
    corners = list(itertools.product((0, 1), repeat=len(C.NAMES)))
    SEARCH = {}
    for q in POWERS:
        dj, dtv = [], []
        for bits in corners:
            x = np.asarray([C.BOUNDS[i][b] for i, b in enumerate(bits)],
                           dtype=float)
            kwP, kwM = C.kw_from_vec(x)
            tp = C.T_IN_REF + kwP.pop("dtin")
            tm = C.T_IN_REF + kwM.pop("dtin")
            rp = C.solve(C.P, q, tp, **kwP)
            rm = C.solve(C.M, q, tm, **kwM)
            dj.append((rm["m"] / rp["m"]) / C.A_R - 1.0)
            dtv.append(C.A_R * rm["d_t_hs"] / rp["d_t_hs"] - 1.0)
        SEARCH[q] = (min(dj), max(dj), min(dtv), max(dtv))
        L("  %5.0f  [%+8.4f, %+8.4f] pct   [%+8.4f, %+8.4f] pct"
          % (q, 100 * min(dj), 100 * max(dj), 100 * min(dtv),
             100 * max(dtv)))
    L("")

    L("[7] three tiers, side by side")
    L("  power  quantity  searched            certified            gap (pp)")
    for q in POWERS:
        sdj, Sdj, sdt, Sdt = SEARCH[q]
        cdj = brs[("dj", q)]
        cdt = brs[("dt", q)]
        L("  %5.0f  D_j       [%+7.3f,%+7.3f]  [%+7.3f,%+7.3f]   %6.3f"
          % (q, 100 * sdj, 100 * Sdj, 100 * cdj[0], 100 * cdj[1],
             100 * ((sdj - cdj[0]) + (cdj[1] - Sdj))))
        L("         D_T       [%+7.3f,%+7.3f]  [%+7.3f,%+7.3f]   %6.3f"
          % (100 * sdt, 100 * Sdt, 100 * cdt[0], 100 * cdt[1],
             100 * ((sdt - cdt[0]) + (cdt[1] - Sdt))))
    L("")
    L("  Conditional tier, for the record.  If D_j is *assumed* to lie inside")
    L("  the searched range -- a premise, not a proof -- the identity carries")
    L("  it to D_T and the width falls to about six points:")
    L("")
    L("  power  assumed D_j            resulting D_T        width")
    for q in POWERS:
        sdj, Sdj, sdt, Sdt = SEARCH[q]
        R = RH[q][0]
        lo = R.lo / (1.0 + Sdj) - 1.0
        hi = R.hi / (1.0 + sdj) - 1.0
        L("  %5.0f  [%+8.4f,%+8.4f] pct  [%+8.4f,%+8.4f]     %6.3f pp"
          % (q, 100 * sdj, 100 * Sdj, 100 * lo, 100 * hi,
             100 * (hi - lo)))
    L("")
    L("  That is the table to quote if the paper already accepts the corner")
    L("  search as sufficient.  It is an analytic range with a stated premise,")
    L("  not a certificate, and it is labelled as such.")
    L("")
    L("  The gap column below is how much wider the certified interval is than the")
    L("  searched range, summed over both ends.  A gap of zero would mean the")
    L("  corner search happened to sit on the true extremes; the number here")
    L("  is the price of certifying the interior, and it is what the next")
    L("  round would have to shrink.")
    L("")
    L("  Apart from the conditional tier, no row above is an analytic")
    L("  envelope with a premise attached: every certified number holds for")
    L("  all inputs in the box, because the temperature window that the")
    L("  property fits require is itself checked as an interval in run_v4b")
    L("  section [6].  That is the difference between the two tables.")
    L("")

    with (ROOT / "results_v4c.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["section", "power_kW", "lo_pct",
                                          "hi_pct", "width_pp", "cells"],
                           extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)
    L("[8] files")
    L("  results_v4c.csv   %d rows" % len(rows))
    L("  run_v4c_log.txt   this log")
    L("  elapsed %.1f s" % (time.time() - t0))
    (ROOT / "run_v4c_log.txt").write_text("\n".join(LINES) + "\n",
                                          encoding="utf-8")


if __name__ == "__main__":
    main()
