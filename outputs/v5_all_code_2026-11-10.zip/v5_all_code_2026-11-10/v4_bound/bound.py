"""bound.py -- certified reductions on the frozen v4 baseline.

Everything here is an *enclosure* argument, not a search: each routine returns
an interval that provably contains the quantity for every point of the
declared input set, and the interval endpoints are outward rounded by ivcore.

The three tools are

  deriv(loop, axis, ...)   certified dPhi/daxis over a box x a flow slab x a
                           power slab, from one dual (value+derivative) march;
  corner(loop, want)       the axis endpoints that minimise or maximise Phi,
                           justified by a certified sign of every dPhi/daxis;
  centered(phi_c, dphi_dT) first-order mean-value form for the one axis whose
                           dPhi/daxis changes sign (the +/-2 K inlet control
                           error), which removes the dependency inflation that
                           plain interval evaluation suffers on that axis.

Phi = dp_buoy - dp_fric, so its root is the accepted flow.
"""

from __future__ import annotations

import core_v2 as C
import ivcore as I

# ------------------------------------------------------------------ axis sets
# Axes that enter only through one side of the comparison.
M_ONLY = ("eps_M", "k_aux_M", "d_hole", "L_HS_M")
P_ONLY = ("dTin_P",)
BOTH = ("u_loss_fac", "mu_fac", "cp_fac", "rho_fac")

# Sign of dPhi/daxis, certified in run_v4b section [1].  +1 means Phi rises
# with the axis, so the minimum of Phi sits at the low end of that axis.
SIGN_PHI = {
    "P": {"u_loss_fac": -1, "mu_fac": -1, "cp_fac": -1, "rho_fac": +1},
    "M": {"eps_M": -1, "k_aux_M": -1, "u_loss_fac": -1, "mu_fac": -1,
          "cp_fac": -1, "rho_fac": +1, "d_hole": +1, "L_HS_M": -1},
}

# Sign of d ln(mM*/mP*)/daxis, certified in run_v4b section [5].  These are
# the axes on which the *ratio* D_j is monotone, which is what allows D_j to
# be enclosed at two corners instead of over the whole box.
SIGN_RATIO = {
    "eps_M": -1, "d_hole": +1, "k_aux_M": -1, "u_loss_fac": +1,
    "mu_fac": +1, "cp_fac": +1, "rho_fac": -1, "L_HS_M": -1,
}

SIDE = {"eps_M": "M", "k_aux_M": "M", "d_hole": "M", "L_HS_M": "M",
        "dTin_P": "P", "dTin_M": "M", "u_loss_fac": "both", "mu_fac": "both",
        "cp_fac": "both", "rho_fac": "both"}
TIN = {"P": "dTin_P", "M": "dTin_M"}


def ax(loop):
    return "M" if loop["label"].startswith("M") else "P"


def margins(loop):
    """(lo, hi) of every axis, as core_v2 declares them."""
    return {n: tuple(b) for n, b in zip(C.NAMES, C.BOUNDS)}


def deriv(loop, axis, q_lo, q_hi, m_iv, cell=None):
    """Certified interval for dPhi/daxis over box x [q_lo,q_hi] x m_iv."""
    o = I.march(loop, **I.box_args_seeded(loop, q_lo, q_hi, 0.0, axis,
                                          cell, m_iv=m_iv))
    return o["dp_buoy"].d - o["dp_fric"].d


def dphi_dm(loop, q_lo, q_hi, m_iv, cell=None):
    return deriv(loop, "m", q_lo, q_hi, m_iv, cell)


def sign_of(iv):
    """'POS', 'NEG' or 'ZERO'."""
    if iv.has_zero():
        return "ZERO"
    return "POS" if iv.lo > 0.0 else "NEG"


def certify(loop, q_lo, q_hi, m_lo, m_hi, axes, nflow=4):
    """Union of dPhi/daxis over a finite cover of a power slab x flow window.

    The flow window is cut into `nflow` slabs because a partial derivative
    that is sign definite on a narrow window need not be so on a wide one;
    the union over the cover is then a certificate on the whole window.
    """
    out = {}
    for k in axes:
        acc = None
        for j in range(nflow):
            a = m_lo + (m_hi - m_lo) * j / nflow
            b = m_lo + (m_hi - m_lo) * (j + 1) / nflow
            d = deriv(loop, k, q_lo, q_hi, (a, b))
            acc = d if acc is None else I.Iv(min(acc.lo, d.lo),
                                             max(acc.hi, d.hi))
        out[k] = acc
    return out


def signs(cert):
    return {k: sign_of(v) for k, v in cert.items()}


def corner(sig, side, want):
    """Cell with every sign-definite axis pinned to one endpoint.

    `sig` maps an axis to the certified sign string of dPhi/daxis and `side`
    is the loop being solved.  want = -1 gives the cell that minimises Phi,
    +1 the one that maximises it.  Axes whose derivative changes sign, and
    axes that do not reach this loop, are left out; the first kind is handled
    by the mean-value form downstream.
    """
    B = margins(C.P)
    cell = {}
    for k, s in sig.items():
        if k not in SIDE or (SIDE[k] != "both" and SIDE[k] != side):
            continue
        if s not in ("POS", "NEG"):
            continue
        lo, hi = B[k]
        cell[k] = (lo, lo) if want * (1 if s == "POS" else -1) < 0 else (hi, hi)
    return cell


def axes_for(side):
    """Axes that actually reach one loop."""
    return tuple(k for k, v in SIDE.items() if v in ("both", side)) + \
        ("Qe",)


def ratio_cell(want):
    """One cell, shared by both loops, on which D_j is extreme.

    Both loops must be evaluated at the *same* axis values, otherwise the
    ratio loses the co-variation that makes it much better determined than
    either flow on its own.  So this pins every axis of SIGN_RATIO, including
    the ones that only reach one side; the other side simply ignores them.
    """
    B = margins(C.P)
    cell = {}
    for k, s in SIGN_RATIO.items():
        lo, hi = B[k]
        cell[k] = (lo, lo) if want * s < 0 else (hi, hi)
    return cell


def point_cell(loop, cell):
    """Complete a cell: pin the inlet-control axis at 0 so the march is a point."""
    c = dict(cell)
    c[TIN[ax(loop)]] = (0.0, 0.0)
    return c


def phi_point(loop, cell, q, m):
    """Phi at one fully pinned input point: a degenerate interval."""
    o = I.march(loop, **I.box_args(loop, q, q, m, point_cell(loop, cell)))
    return o["dp_buoy"].v - o["dp_fric"].v, o


def phi_env(loop, cell, q, m, dtin_der):
    """Phi over the cell and over the +/-2 K inlet error, centred form.

    Phi(T_in) - Phi(0) = Phi'(xi) T_in for some xi on the segment, and
    `dtin_der` encloses Phi' over the whole box, so the product is a valid
    enclosure.  Plain interval evaluation of the same 4 K span is about 130
    times wider (see the log, section [1]).
    """
    p, o = phi_point(loop, cell, q, m)
    return p + dtin_der * I.Iv(-2.0, 2.0), o


def phi_slab(loop, cell, q_lo, q_hi, m, dtin_der):
    """Same, but with the power kept as an interval instead of a point.

    Needed where the two loops have to be compared at the *same* power: there
    the power end cannot be pinned independently for each loop, so the slab is
    carried as an interval and the enclosure widens accordingly.
    """
    o = I.march(loop, **I.box_args(loop, q_lo, q_hi, m,
                                   point_cell(loop, cell)))
    p = o["dp_buoy"].v - o["dp_fric"].v
    return p + dtin_der * I.Iv(-2.0, 2.0), o


def _bisect(pred, a, b, iters, tol):
    """Shrink [a,b] to the boundary of a monotone boolean predicate.

    `pred(a)` must hold and `pred(b)` must fail; the returned pair keeps that
    property and its width is below `tol` relative.
    """
    n = 0
    while b - a > tol * a and n < iters:
        mid = 0.5 * (a + b)
        if pred(mid):
            a = mid
        else:
            b = mid
        n += 1
    return a, b, n


def bracket(loop, q_lo, q_hi, cell_lo, cell_hi, m_lo, m_hi, dtin_der,
            iters=44, tol=2e-4, pin_q=True):
    """Flow interval that contains the root for every input in the set.

    `cell_lo` is the Phi-minimising cell and `cell_hi` the Phi-maximising one.
    With `pin_q` the low test is taken at q_lo and the high test at q_hi, which
    is exact because dPhi/dQ > 0 is certified.  Without it the power slab is
    carried as an interval, which is what comparing the two loops at the same
    power requires.

    Two independent monotone searches: the largest flow at which Phi is still
    positive everywhere, and the smallest flow at which Phi is negative
    everywhere.  Everything in between is the certified root interval.
    """
    if pin_q:
        def low_phi(m):
            return phi_env(loop, cell_lo, q_lo, m, dtin_der)[0]

        def high_phi(m):
            return phi_env(loop, cell_hi, q_hi, m, dtin_der)[0]
    else:
        def low_phi(m):
            return phi_slab(loop, cell_lo, q_lo, q_hi, m, dtin_der)[0]

        def high_phi(m):
            return phi_slab(loop, cell_hi, q_lo, q_hi, m, dtin_der)[0]

    def low_ok(m):
        return low_phi(m).lo > 0.0

    def high_ok(m):
        return high_phi(m).hi < 0.0

    if not low_ok(m_lo):
        raise RuntimeError("lower end is not positive at m=%g" % m_lo)
    if not high_ok(m_hi):
        raise RuntimeError("upper end is not negative at m=%g" % m_hi)
    a, _, n1 = _bisect(low_ok, m_lo, m_hi, iters, tol)
    _, b, n2 = _bisect(lambda m: not high_ok(m), m_lo, m_hi, iters, tol)
    return a, b, n1 + n2


def root_at(loop, cell, q, dtin_der, m_guess, rel=0.25, iters=44):
    """Bracket of the root inside one cell at one power."""
    m_lo = m_guess * (1.0 - rel)
    m_hi = m_guess * (1.0 + rel)
    return bracket(loop, q, q, cell, cell, m_lo, m_hi, dtin_der, iters)
