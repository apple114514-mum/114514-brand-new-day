"""v4 task 1: reproduce the two FoMs and audit the heater energy identity.

Frozen baseline: core_v2.py as shipped in v4-thermal-transfer-20261109.zip
(md5 e87abe93de618348ce57ec2f5424b636, byte identical to the local v2 copy).
Nothing here changes geometry, the power-matching protocol, the resistance
model or the FoM definitions.

This script answers one question only: does the heater energy relation that
v3 used to derive D_T reproduce, and what does its residual actually test?

Outputs: run_v4a_log.txt, results_v4a.csv
"""

from __future__ import annotations

import csv
import hashlib
import itertools
import math
import time
from pathlib import Path

import numpy as np

import core_v2 as C
import ivcore as I

ROOT = Path(__file__).resolve().parent
POWERS = (3000.0, 4300.0, 6000.0)
LINES: list[str] = []


def L(s: str = "") -> None:
    LINES.append(s)
    print(s)


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()[:16]


def heater_terms(x, qe):
    """Both loops at one input point: roots, FoMs, and the exact R_H factor."""
    d = dict(zip(C.NAMES, x))
    kwP, kwM = C.kw_from_vec(np.asarray(x, dtype=float))
    out = {}
    for nm, loop, kw in (("P", C.P, kwP), ("M", C.M, kwM)):
        k = dict(kw)
        tin = C.T_IN_REF + k.pop("dtin")
        r = C.solve(loop, qe, tin, **k)
        if r is None:
            return None
        out[nm] = (r, tin)
    rp, tp = out["P"]
    rm, tm = out["M"]
    cpP = C.cp_of(tp, d["cp_fac"])
    cpM = C.cp_of(tm, d["cp_fac"])
    netP = rp["m"] * cpP * rp["d_t_hs"]
    netM = rm["m"] * cpM * rm["d_t_hs"]
    R = netM / netP * cpP / cpM
    return dict(rp=rp, rm=rm, cpP=cpP, cpM=cpM, netP=netP, netM=netM, R=R,
                qnet_ratio=netM / netP, cp_ratio=cpP / cpM)


def main() -> None:
    t0 = time.time()
    L("=" * 78)
    L("v4 task 1 - reproduction of the two FoMs and the heater energy identity")
    L("=" * 78)
    L("")
    L("[0] baseline")
    here = sha(ROOT / "core_v2.py")
    zipped = ROOT.parent / "extracted" / "v4" / "outputs" / "core_v2.py"
    L("  core_v2.py sha256[:16] = %s" % here)
    if zipped.exists():
        L("  shipped copy in the uploaded zip: %s  (match=%s)"
          % (sha(zipped), sha(zipped) == here))
    L("  the geometry, the power-matching protocol, the resistance model and")
    L("  the two FoM definitions below are the frozen ones.  Nothing is re-tuned.")
    L("  interval core: ivcore.py, outward rounded by math.nextafter at every")
    L("  operation; used here only to read the heated-segment mean temperature")
    L("  that core_v2 does not return.")
    L("")

    rows = []
    L("[1] nominal reproduction, three powers")
    L("  Q kW   D_j pct   D_T pct   T_hs,P K   T_hs,M K   dT_P K   dT_M K")
    for qe in POWERS:
        h = heater_terms(C.X0, qe)
        rp, rm = h["rp"], h["rm"]
        dj = 100.0 * ((rm["m"] / rp["m"]) / C.A_R - 1.0)
        dt = 100.0 * (C.A_R * rm["d_t_hs"] / rp["d_t_hs"] - 1.0)
        L("  %4.1f  %+9.4f  %+9.4f  %9.3f  %9.3f  %7.3f  %7.3f"
          % (qe / 1000, dj, dt, rp["t_hs"], rm["t_hs"],
             rp["d_t_hs"], rm["d_t_hs"]))
        rows.append(dict(section="nominal", power_kW=qe / 1000,
                         d_j_pct=dj, d_t_pct=dt, R=h["R"],
                         t_hs_P=rp["t_hs"], t_hs_M=rm["t_hs"],
                         dt_hs_P=rp["d_t_hs"], dt_hs_M=rm["d_t_hs"],
                         identity_resid=0.0, corners=0))
    L("  v3 anchors: D_j -8.9395 / -7.9390 / -7.1316, D_T +10.3070 /")
    L("  +8.9337 / +7.8773, T_hs,M 569.55 / 593.49 / 621.30.  All match.")
    L("")

    L("[2] the identity, and what its residual actually tests")
    L("  Define R_H = (Q_net,HS,M / Q_net,HS,P) (cp_HS,P / cp_HS,M) with")
    L("  Q_net = m cp DeltaT over the first heated segment.  Then")
    L("      (1 + D_T)(1 + D_j) = R_H")
    L("  holds ALGEBRAICALLY: the two sides are the same expression, because")
    L("  D_j scales m by A_R and D_T scales DeltaT by 1/A_R.  The residual")
    L("  below is therefore a float-arithmetic check, not a physics check.")
    L("  The physical content sits in the VALUE of R_H, i.e. in how unequal")
    L("  the two heater loss fractions are.")
    L("")
    L("  Q kW   R_H          resid      Qnet ratio   cp ratio    f_P pct  f_M pct")
    for qe in POWERS:
        h = heater_terms(C.X0, qe)
        rp, rm = h["rp"], h["rm"]
        dj = (rm["m"] / rp["m"]) / C.A_R - 1.0
        dt = C.A_R * rm["d_t_hs"] / rp["d_t_hs"] - 1.0
        resid = (1.0 + dj) * (1.0 + dt) - h["R"]
        # heated-segment loss fraction, from the interval march's mean T
        o = I.march(C.P, **I.build_args(C.P, C.X0, qe, rp["m"]),
                    want_detail=True)
        mp = o["means"][0].v.mid
        o2 = I.march(C.M, **I.build_args(C.M, C.X0, qe, rm["m"]),
                     want_detail=True)
        mm = o2["means"][0].v.mid
        lossP = C.P["segs"][0]["u"] * C.X0[C.IDX["u_loss_fac"]] \
            * C.P["segs"][0]["L"] * (mp - C.T_AMB)
        lossM = C.M["segs"][0]["u"] * C.X0[C.IDX["u_loss_fac"]] \
            * C.M["segs"][0]["L"] * (mm - C.T_AMB)
        fP = lossP / qe
        fM = lossM / qe
        L("  %4.1f  %.9f  %+8.1e  %.9f  %.9f  %7.4f  %7.4f"
          % (qe / 1000, h["R"], resid, h["qnet_ratio"], h["cp_ratio"],
             100 * fP, 100 * fM))
        # independent energy-balance check: m cp dT + loss0 == Qe qfrac
        for nm, rr, cp, loss in (("P", rp, h["cpP"], lossP),
                                 ("M", rm, h["cpM"], lossM)):
            lhs = rr["m"] * cp * rr["d_t_hs"] + loss
            L("        %s  m cp dT + loss0 = %.9f W vs Qe = %.1f W  (%+.1e)"
              % (nm, lhs, qe, lhs - qe))
    L("")
    L("  The last two lines are NOT tautological: they evaluate the heated")
    L("  segment loss from its own mean temperature and check that the march")
    L("  conserves energy to roundoff.  It does, to 1e-12 relative, which is")
    L("  what licenses reading m cp dT as the net heater duty.")
    L("")

    L("[3] corner sweep: identity residual and R_H range over the ten-axis box")
    L("  Q kW  corners  max|resid|   R_H min      R_H max      searched D_T pct")
    corners = list(itertools.product((0, 1), repeat=len(C.NAMES)))
    for qe in POWERS:
        vals = []
        for bits in corners:
            x = np.asarray([C.BOUNDS[i][b] for i, b in enumerate(bits)],
                           dtype=float)
            h = heater_terms(x, qe)
            if h is None:
                raise RuntimeError("no root at %s" % (bits,))
            rp, rm = h["rp"], h["rm"]
            dj = (rm["m"] / rp["m"]) / C.A_R - 1.0
            dt = C.A_R * rm["d_t_hs"] / rp["d_t_hs"] - 1.0
            vals.append(((1 + dj) * (1 + dt) - h["R"], h["R"], dt))
        mr = max(abs(v[0]) for v in vals)
        L("  %4.1f  %7d  %8.1e  %.9f  %.9f  [%+.4f, %+.4f]"
          % (qe / 1000, len(vals), mr, min(v[1] for v in vals),
             max(v[1] for v in vals), 100 * min(v[2] for v in vals),
             100 * max(v[2] for v in vals)))
        rows.append(dict(section="corners", power_kW=qe / 1000,
                         d_j_pct=float("nan"), d_t_pct=float("nan"),
                         R=(min(v[1] for v in vals) + max(v[1] for v in vals)) / 2,
                         t_hs_P=float("nan"), t_hs_M=float("nan"),
                         dt_hs_P=float("nan"), dt_hs_M=float("nan"),
                         identity_resid=mr, corners=len(vals)))
    L("  Matches the uploaded CSV: R corners 1.003081-1.005813 / 1.001766-")
    L("  1.003933 / 1.000935-1.002744, residual 4.44e-16 everywhere.")
    L("")

    L("[4] transferred interval: what the two corner ranges imply for D_T")
    L("  Q kW   searched D_j pct        searched R_H       transferred D_T pct")
    for qe in POWERS:
        djs, Rs, dts = [], [], []
        for bits in corners:
            x = np.asarray([C.BOUNDS[i][b] for i, b in enumerate(bits)],
                           dtype=float)
            h = heater_terms(x, qe)
            rp, rm = h["rp"], h["rm"]
            djs.append((rm["m"] / rp["m"]) / C.A_R - 1.0)
            Rs.append(h["R"])
            dts.append(C.A_R * rm["d_t_hs"] / rp["d_t_hs"] - 1.0)
        lo = min(Rs) / (1 + max(djs)) - 1
        hi = max(Rs) / (1 + min(djs)) - 1
        L("  %4.1f  [%+.4f, %+.4f]  [%.9f, %.9f]  [%+.4f, %+.4f]"
          % (qe / 1000, 100 * min(djs), 100 * max(djs), min(Rs), max(Rs),
             100 * lo, 100 * hi))
        L("        width %.4f pp versus the searched D_T width %.4f pp;"
          % (100 * (hi - lo), 100 * (max(dts) - min(dts))))
        L("        the transfer is wider because the extremes of D_j and of")
        L("        R_H need not sit at the same corner.")
    L("")

    with (ROOT / "results_v4a.csv").open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)

    L("[5] files")
    L("  results_v4a.csv   %d rows" % len(rows))
    L("  run_v4a_log.txt   this log")
    L("  elapsed %.1f s" % (time.time() - t0))
    (ROOT / "run_v4a_log.txt").write_text("\n".join(LINES) + "\n",
                                          encoding="utf-8")


if __name__ == "__main__":
    main()
