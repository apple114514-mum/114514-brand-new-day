"""Sanity check: do random points of the declared box respect the two bounds?

Not a proof -- a proof by sampling is exactly what this project keeps refusing
to accept.  It is here as a falsification test: one point outside a claimed
outer bound kills that bound, so a few thousand draws that all land inside are
worth reporting alongside the certificate.

Usage: python mc_check.py [n]
"""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "v4_bound"))

import core_v2 as C  # noqa: E402

V7 = (-35.19736257, 29.73966069)
V5 = (-18.6573, 2.6803)


def main() -> None:
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 1500
    rng = np.random.default_rng(20261110)
    vals, miss = [], 0
    for _ in range(n):
        x = np.array([rng.uniform(lo, hi) for lo, hi in C.BOUNDS])
        q = rng.uniform(3000.0, 6000.0)
        kw_p, kw_m = C.kw_from_vec(x)
        d = dict(zip(C.NAMES, x))
        rp = C.solve(C.P, q, C.T_IN_REF + d["dTin_P"], **kw_p)
        rm = C.solve(C.M, q, C.T_IN_REF + d["dTin_M"], **kw_m)
        if rp is None or rm is None:
            miss += 1
            continue
        vals.append((rm["m"] / rp["m"]) / C.A_R - 1.0)
    v = 100.0 * np.array(vals)
    print("draws %d, rejected %d, kept %d" % (n, miss, len(v)))
    print("D_j range  [%.4f, %.4f] pct,  width %.4f pp"
          % (v.min(), v.max(), v.max() - v.min()))
    print("inside v7 %s: %s" % (V7, bool(v.min() >= V7[0] and v.max() <= V7[1])))
    print("inside v5 %s: %s" % (V5, bool(v.min() >= V5[0] and v.max() <= V5[1])))


if __name__ == "__main__":
    main()
