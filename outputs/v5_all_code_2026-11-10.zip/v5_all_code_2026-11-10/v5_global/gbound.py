"""v5: extend the v4 D_j certificate from three powers to the whole 3-6 kW range.

The v4 result certified D_j at 3, 4.3 and 6 kW separately.  The v7 package
(prior-distortion-v7-continuous-proof-20261110) certifies the continuous power
axis jointly but with a wide enclosure [-35.198, +29.740] %.  This script
carries the v4 machinery over the power axis in six closed 500 W slabs, each
with its own certified flow bracket, and takes the union.

Nothing in the model changes: same frozen core_v2, same ten axes, same signs.

Two facts make the slab exact rather than sampled:
  dPhi/dQ > 0 is certified, so on a slab the minimum of Phi sits at q_lo and
  the maximum at q_hi.  The flow bracket of a slab is therefore the certified
  bracket of the whole slab, and the union over six slabs covers [3, 6] kW.

The flow window handed to the per-cell bisection is the slab bracket from the
corner reduction, not a guessed +-12 % band.  That matters: an interval
enclosure of Phi is not monotone in m, so the bisection returns the last point
where the sign was *certified*, and starting it from a window that is already
certified to contain the root is what keeps it sharp.
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "v4_bound"))

import core_v2 as C          # noqa: E402
import bound as B            # noqa: E402

A_R = C.A_R
N_SLAB = 6
SLABS = [(3000.0 + 500.0 * j, 3000.0 + 500.0 * (j + 1)) for j in range(N_SLAB)]
DJ_SPLIT = ("u_loss_fac", "mu_fac", "cp_fac", "rho_fac")
DJ_PIN = ("eps_M", "k_aux_M", "d_hole", "L_HS_M")
SIG_R = B.SIGN_RATIO
SIG_PHI = B.SIGN_PHI
SIDE = B.SIDE


def corner(side, want):
    """Cell that minimises (want=-1) or maximises (+1) Phi on one side."""
    Bm = B.margins(C.P)
    cell = {}
    for k, s in SIG_PHI[side].items():
        if SIDE.get(k) not in (side, "both"):
            continue
        lo, hi = Bm[k]
        cell[k] = (lo, lo) if want * s < 0 else (hi, hi)
    return cell


def pin_cell(want):
    """The four M-only axes at the endpoint that pushes D_j down or up."""
    Bm = B.margins(C.P)
    cell = {}
    for k in DJ_PIN:
        lo, hi = Bm[k]
        s = SIG_R[k]
        cell[k] = (lo, lo) if want * s < 0 else (hi, hi)
    return cell


def split_cells(k):
    Bm = B.margins(C.P)
    out = [{}]
    for name in DJ_SPLIT:
        lo, hi = Bm[name]
        nxt = []
        for cell in out:
            for j in range(k):
                c = dict(cell)
                c[name] = (lo + (hi - lo) * j / k, lo + (hi - lo) * (j + 1) / k)
                nxt.append(c)
        out = nxt
    return out


def dtin_der(loop, side, q_lo, q_hi, win):
    """Certified dPhi/dT_in over the slab, the box and a flow window."""
    return B.deriv(loop, "dTin_" + side, q_lo, q_hi, win)


def slab_window(q_lo, q_hi):
    """Certified flow bracket of one slab, from the corner reduction.

    Iterated: the mean-value term for the +-2 K inlet error needs a certified
    dPhi/dT_in over the very flow window the bisection searches, and a window
    that is already certified to contain the root gives a much tighter
    derivative than a guessed +-20 % band.  Each pass is valid on its own
    (tightening the derivative enclosure can only strengthen the sign tests),
    so the last window returned is a certificate, not an iteration artefact.
    """
    out, der = {}, {}
    for side, loop in (("P", C.P), ("M", C.M)):
        win = (0.50, 0.90) if side == "P" else (0.16, 0.34)
        d = None
        for _ in range(3):
            d = dtin_der(loop, side, q_lo, q_hi, win)
            a, b, _ = B.bracket(loop, q_lo, q_hi, corner(side, -1),
                                corner(side, +1), win[0], win[1], d, tol=2e-4)
            # The derivative enclosure `d` is valid over `win`, so the next
            # window has to stay inside it; the clamp keeps that true even
            # when the padding would otherwise reach past it.
            win = (max(a * (1.0 - 4e-2), win[0]), min(b * (1.0 + 4e-2), win[1]))
        out[side] = win
        der[side] = d
    return out, der


def cell_bound(q_lo, q_hi, cell, win, der, tol=1e-3):
    lo, hi = 1e9, -1e9
    for want in (-1, +1):
        cc = dict(cell)
        cc.update(pin_cell(want))
        ap, bp, _ = B.bracket(C.P, q_lo, q_hi, cc, cc, win["P"][0], win["P"][1],
                              der["P"], tol=tol)
        am, bm, _ = B.bracket(C.M, q_lo, q_hi, cc, cc, win["M"][0], win["M"][1],
                              der["M"], tol=tol)
        lo = min(lo, (am / bp) / A_R - 1.0)
        hi = max(hi, (bm / ap) / A_R - 1.0)
    return lo, hi


def slab_bound(q_lo, q_hi, cells, tol=1e-3):
    win, der = slab_window(q_lo, q_hi)
    lo, hi = 1e9, -1e9
    for cell in cells:
        a, b = cell_bound(q_lo, q_hi, cell, win, der, tol=tol)
        lo = min(lo, a)
        hi = max(hi, b)
    return lo, hi, win


def main() -> None:
    t0 = time.time()
    print("=" * 78)
    print("v5 - D_j certified over the continuous power axis, 3-6 kW")
    print("=" * 78)
    print("  frozen core_v2, ten-axis box, six closed 500 W slabs")
    print("  Phi = dp_buoy - dp_fric; root = accepted flow; dPhi/dQ > 0")
    print("")

    print("[1] per-slab certified flow brackets (the window for what follows)")
    print("  slab        P lo       P hi       M lo       M hi")
    wins = {}
    for q_lo, q_hi in SLABS:
        win, _ = slab_window(q_lo, q_hi)
        wins[(q_lo, q_hi)] = win
        print("  %5.0f-%5.0f  %9.6f  %9.6f  %9.6f  %9.6f"
              % (q_lo, q_hi, win["P"][0], win["P"][1],
                 win["M"][0], win["M"][1]))
    print("")

    print("[2] convergence on the first slab, shared-axis grid k^4")
    print("  k    cells   D_j lower    D_j upper   width pp   seconds")
    cells4 = None
    for k in (1, 2, 3, 4):
        t = time.time()
        cells = split_cells(k)
        lo, hi, _ = slab_bound(3000.0, 3500.0, cells)
        if k == 4:
            cells4 = cells
        print("  %d   %6d   %+10.4f   %+10.4f   %7.4f   %6.1f"
              % (k, len(cells), 100 * lo, 100 * hi, 100 * (hi - lo),
                 time.time() - t))

    print("")
    print("[3] all six slabs at k=4, union over the power axis")
    print("  slab         D_j lower   D_j upper   width pp")
    lo_all, hi_all = 1e9, -1e9
    for q_lo, q_hi in SLABS:
        lo, hi, _ = slab_bound(q_lo, q_hi, cells4)
        lo_all = min(lo_all, lo)
        hi_all = max(hi_all, hi)
        print("  %5.0f-%5.0f   %+10.4f   %+10.4f   %7.4f"
              % (q_lo, q_hi, 100 * lo, 100 * hi, 100 * (hi - lo)))
    print("")
    print("  UNION over 3000-6000 W: [%+.4f, %+.4f] pct, width %.4f pp"
          % (100 * lo_all, 100 * hi_all, 100 * (hi_all - lo_all)))
    print("  elapsed %.1f s" % (time.time() - t0))


if __name__ == "__main__":
    main()
