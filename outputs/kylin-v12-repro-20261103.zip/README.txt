Place both .py files in the same folder; run: python closure_v12.py
The script writes closure_v12_log.txt beside itself. Historical numeric output is an arithmetic reproduction, not physical validation.
