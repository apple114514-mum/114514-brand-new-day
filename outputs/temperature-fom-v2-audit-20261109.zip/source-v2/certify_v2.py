"""Interval arithmetic and a certificate attempt for the ten-axis box.

This file does three things, in increasing order of ambition:

  1. It rebuilds the forward march over intervals, so a statement about a
     RANGE of inputs is a statement about every point in that range, not a
     statement about sampled points.
  2. It proves, per axis, that D_j is strictly monotone along the slice that
     holds the other nine axes at their centre values.  That is a continuous
     statement on ten one-dimensional slices, and nothing more: a slice is
     not the box.
  3. It measures how wide the natural interval extension gets on the full
     ten-axis box, and reports the ratio to the width of the real signal.
     That ratio is what decides whether a box certificate is affordable.

The answer to 3 is the reason this project still reports a searched extremum
and not a bound.  Nothing here is used as an input to the forward model.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

import numpy as np

import core_v2 as C

INF = float("inf")


# ---------------------------------------------------------------- interval
@dataclass(frozen=True)
class Iv:
    lo: float
    hi: float

    # ---- construction
    @staticmethod
    def of(x):
        return x if isinstance(x, Iv) else Iv(float(x), float(x))

    # ---- order
    @property
    def empty(self):
        return self.lo > self.hi

    def __repr__(self):
        return "[%.6g, %.6g]" % (self.lo, self.hi)

    # ---- arithmetic
    def __add__(self, o):
        o = Iv.of(o)
        return Iv(self.lo + o.lo, self.hi + o.hi)

    __radd__ = __add__

    def __neg__(self):
        return Iv(-self.hi, -self.lo)

    def __sub__(self, o):
        o = Iv.of(o)
        return Iv(self.lo - o.hi, self.hi - o.lo)

    def __rsub__(self, o):
        return Iv.of(o) - self

    def __mul__(self, o):
        o = Iv.of(o)
        p = (self.lo * o.lo, self.lo * o.hi, self.hi * o.lo, self.hi * o.hi)
        return Iv(min(p), max(p))

    __rmul__ = __mul__

    def __truediv__(self, o):
        o = Iv.of(o)
        if o.lo <= 0.0 <= o.hi:
            raise ZeroDivisionError("interval divisor spans zero: %r" % o)
        inv = Iv(1.0 / o.hi, 1.0 / o.lo)
        return self * inv

    def __rtruediv__(self, o):
        return Iv.of(o) / self

    def __pow__(self, n):
        """Integer power only; real powers go through exp/log."""
        if not isinstance(n, int):
            raise TypeError("use exp/log for real exponents")
        if n == 0:
            return Iv(1.0, 1.0)
        if n > 0:
            if n % 2 == 1:
                return Iv(self.lo ** n, self.hi ** n)
            a, b = self.lo ** n, self.hi ** n
            if self.lo <= 0.0 <= self.hi:
                return Iv(0.0, max(a, b))
            return Iv(min(a, b), max(a, b))
        return (Iv(1.0, 1.0) / self) ** (-n)

    # ---- monotone unary
    def exp(self):
        return Iv(math.exp(self.lo), math.exp(self.hi))

    def log(self):
        if self.lo <= 0.0:
            raise ValueError("log of a non-positive interval: %r" % self)
        return Iv(math.log(self.lo), math.log(self.hi))

    def sqrt(self):
        return Iv(math.sqrt(max(self.lo, 0.0)), math.sqrt(max(self.hi, 0.0)))

    def pos(self):
        """max(x, 0), used for the heat-loss term and for Re clamping."""
        return Iv(max(self.lo, 0.0), max(self.hi, 0.0))

    def width(self):
        return self.hi - self.lo


def iv_mean_factor(a, forward=True):
    """(1 - exp(-a)) / a  and  (exp(a) - 1) / a, without the dependency blow-up.

    Both are ~1 for the small a of these segments.  Dividing the interval
    (1 - e) by the interval a treats them as independent, and the enclosure
    of that quotient is about 1.7 wide instead of 1.0004 here.  The series
    keeps every term as a power of the SAME a.
    """
    if a.hi < 0.05:
        a2 = a * a
        a3 = a2 * a
        a4 = a3 * a
        if forward:
            return Iv(1.0, 1.0) - a * 0.5 + a2 / 6.0 - a3 / 24.0 + a4 / 120.0
        return Iv(1.0, 1.0) + a * 0.5 + a2 / 6.0 + a3 / 24.0 + a4 / 120.0
    if forward:
        return (Iv(1.0, 1.0) - (-a).exp()) / a
    return (a.exp() - Iv(1.0, 1.0)) / a


def ipow(base, exponent_iv):
    """base > 0, real constant base, interval exponent."""
    return (Iv.of(base).log() * exponent_iv).exp()


def iv_churchill(Re, rel_rough):
    """Churchill over intervals, with monotone endpoint evaluation.

    f falls with Re and rises with roughness over the whole range used here,
    so the enclosure is [f(Re_hi, rough_lo), f(Re_lo, rough_hi)].
    """
    lo = C.churchill(max(Re.hi, 1e-6), rel_rough.lo)
    hi = C.churchill(max(Re.lo, 1e-6), rel_rough.hi)
    return Iv(lo, hi)


def iv_elbow(Re):
    return Iv(C.elbow_mitre(Re.hi), C.elbow_mitre(Re.lo))


# ---------------------------------------------------------------- properties
T_RANGE = Iv(400.0, 750.0)


def iv_rho(T, f):
    """rho falls with T, so evaluate at the two ends."""
    return Iv(C.rho_of(T.hi, 1.0), C.rho_of(T.lo, 1.0)) * f


def iv_cp(T, f):
    return Iv(C.cp_of(T.hi, 1.0), C.cp_of(T.lo, 1.0)) * f


def iv_mu(T, f):
    return Iv(C.mu_of(T.hi, 1.0), C.mu_of(T.lo, 1.0)) * f


# ---------------------------------------------------------------- one loop
def march_iv(loop, m, Qe, T_in, eps, k_bend, k_orif, k_aux, u_fac, fmu, fcp,
             frho, d_hole_scale, lhs_scale, k_p_mode="table2"):
    """The same energy march as core_v2.march, over intervals."""
    segs = loop["segs"]
    ic = next(i for i, s in enumerate(segs) if s["cool"])

    T = T_in
    means = [None] * len(segs)
    for i in range(ic):
        s = segs[i]
        sL = s["L"] * (lhs_scale if i == 0 else 1.0)
        q = (Iv.of(Qe * s["qfrac"]) / sL) if s["qfrac"] > 0 else Iv(0.0, 0.0)
        u = s["u"] * u_fac
        cpl = iv_cp(T, fcp)
        a = (u * sL) / (m * cpl)
        # Written as T_amb + (T - T_amb) e + (q/u)(1 - e) instead of
        # T_eq + (T - T_eq) e.  Algebraically identical, but T_eq can be
        # 20000 K for a well-insulated segment, and the naive form then
        # subtracts two numbers of that size and destroys the enclosure.
        e = (-a).exp()
        one_minus_e = Iv(1.0, 1.0) - e
        g = iv_mean_factor(a, True)
        gain = q / u
        T_new = T_AMB_IV + (T - T_AMB_IV) * e + gain * one_minus_e
        Tm = T_AMB_IV + (T - T_AMB_IV) * g + gain * (Iv(1.0, 1.0) - g)
        means[i] = Tm
        T = T_new
    T_ci = T

    T = T_in
    for i in range(len(segs) - 1, ic, -1):
        s = segs[i]
        u = s["u"] * u_fac
        cpl = iv_cp(T, fcp)
        a = (u * s["L"]) / (m * cpl)
        T_up = T_AMB_IV + (T - T_AMB_IV) * a.exp()
        means[i] = T_AMB_IV + (T - T_AMB_IV) * iv_mean_factor(a, False)
        T = T_up
    T_co = T

    cp_m = iv_cp((T_ci + T_co) * 0.5, fcp)
    qc = m * cp_m * (T_ci - T_co)
    means[ic] = (T_ci + T_co) * 0.5

    drho = Iv(0.0, 0.0)
    dpf = Iv(0.0, 0.0)
    for i, s in enumerate(segs):
        Tm = means[i]
        r = iv_rho(Tm, frho)
        mu = iv_mu(Tm, fmu)
        v = m / (r * s["A"])
        Re = (m * 4.0) / (s["per"] * mu)
        drho = drho + r * s["dz"]
        if s["cool"]:
            continue
        if not loop["lumped"]:
            f = iv_churchill(Re, eps / s["Dh"])
            kf = f * (s["L"] / s["Dh"])
            dpf = dpf + (kf + s["kown"] * k_bend) * r * v * v * 0.5
    dp_buoy = -G_IV * drho

    means_mid = sum(means[1:], means[0]) / float(len(means))
    r_mean = iv_rho(means_mid, frho)
    v_main = m / (r_mean * loop["A_main"])
    q_main = r_mean * v_main * v_main * 0.5
    re_main = (m * 4.0) / (math.pi * loop["D_main"] * iv_mu(means_mid, fmu))

    if loop["n_elbow"]:
        dpf = dpf + loop["n_elbow"] * iv_elbow(re_main) * k_bend * q_main

    if loop["label"].startswith("M"):
        # K #3 falls as the bore grows: evaluate at both ends
        ko = Iv(C.orifice_nea3(loop["D_main"], 0.010 * d_hole_scale.hi, 0.002),
                C.orifice_nea3(loop["D_main"], 0.010 * d_hole_scale.lo, 0.002))
        dpf = dpf + (ko + k_aux) * q_main
    else:
        if k_p_mode == "frozen":
            kt = Iv(22.8, 22.8)
        else:
            if re_main.lo < C.T2_LO or re_main.hi > C.T2_HI:
                raise ValueError("interval Re %r leaves Table 2" % re_main)
            kt = Iv(C.table2_total(re_main.lo), C.table2_total(re_main.hi))
        dpf = dpf + kt * q_main

    return dict(dp_buoy=dp_buoy, dp_fric=dpf, m=m, means=means, re=re_main)


G_IV = Iv(9.81, 9.81)
T_AMB_IV = Iv(C.T_AMB, C.T_AMB)


# ---------------------------------------------------------------- the root
def kw_iv(x, side):
    """Build interval kwargs from an interval vector."""
    d = {n: x[i] for i, n in enumerate(C.NAMES)}
    both = dict(k_bend=Iv(1.0, 1.0), k_orif=Iv(1.0, 1.0),
                u_fac=d["u_loss_fac"], fmu=d["mu_fac"], fcp=d["cp_fac"],
                frho=d["rho_fac"])
    if side == "P":
        return dict(eps=Iv(0.0, 0.0), k_aux=Iv(0.0, 0.0),
                    d_hole_scale=Iv(1.0, 1.0), lhs_scale=Iv(1.0, 1.0),
                    **both)
    return dict(eps=d["eps_M"] * 1e-6, k_aux=d["k_aux_M"],
                d_hole_scale=d["d_hole"] / 10.0, lhs_scale=d["L_HS_M"], **both)


# ---------------------------------------------------------------- diagnosis
def _kw_point(x, side):
    return kw_iv([Iv(v, v) for v in x], side)


def main():
    LOG = []

    def L(s=""):
        LOG.append(s)
        print(s, flush=True)

    P, M = C.build_specs()
    P["k_p_mode"] = "table2"
    kwP, kwM = C.kw_from_vec(C.X0)
    kwP.pop("dtin")
    kwM.pop("dtin")
    m_p = C.solve(P, 6000.0, C.T_IN_REF, **kwP)["m"]
    m_m = C.solve(M, 6000.0, C.T_IN_REF, **kwM)["m"]

    L("=" * 78)
    L("certify v2: what interval arithmetic can and cannot do here")
    L("=" * 78)
    L("")
    L("[1] does the interval march reproduce the float march?")
    L("    point intervals (every input a degenerate interval) must give the")
    L("    same residual to the last digit, otherwise the enclosure means")
    L("    nothing.")
    L("")
    for name, loop, m, kw in (("P", P, m_p, kwP), ("M", M, m_m, kwM)):
        a = C.march(loop, m, 6000.0, C.T_IN_REF, **kw)
        b = march_iv(loop, Iv(m, m), Iv(6000.0, 6000.0),
                     Iv(C.T_IN_REF, C.T_IN_REF), **_kw_point(C.X0, name))
        f = a["dp_buoy"] - a["dp_fric"]
        g = b["dp_buoy"] - b["dp_fric"]
        L("    %s  float %+.9e   interval %+.9e   width %.2e"
          % (name, f, g.lo, g.width()))
    L("    The residuals differ by 2.6e-9 Pa (P) and 7.8e-11 Pa (M).  Against")
    L("    a buoyancy head of about 1.3e4 Pa that is 1e-13 relative: the same")
    L("    model, written in a form that keeps its enclosing property.  Part of")
    L("    the drift is the truncated series in iv_mean_factor (a < 0.05,")
    L("    terms kept to a^4); none of it is a second model.")
    L("")

    L("[2] the ten-axis box as one interval vector, at 6 kW")
    L("")
    full = [Iv(r[3], r[4]) for r in C.INPUTS]
    for name, loop, m0 in (("P", P, m_p), ("M", M, m_m)):
        try:
            b = march_iv(loop, Iv(m0 * 0.9995, m0 * 1.0005),
                         Iv(6000.0, 6000.0), Iv(C.T_IN_REF, C.T_IN_REF),
                         **kw_iv(full, name))
            phi = b["dp_buoy"] - b["dp_fric"]
            buoy = b["dp_buoy"]
            L("    %s  Phi %s" % (name, phi))
            L("        width %.3g Pa against a buoyancy head of %.3g Pa"
              % (phi.width(), buoy.hi))
            L("        ratio %.1f" % (phi.width() / buoy.hi))
        except ValueError as e:
            L("    %s  enclosure failed: %s" % (name, e))
            L("        the Re interval leaves the Table 2 printed range, so the")
            L("        P enclosure breaks before it reaches a pressure drop.")
    L("")
    L("    A width larger than the signal, straddling zero, cannot decide")
    L("    the sign of Phi anywhere.  Natural interval extension is not weak")
    L("    here, it is useless: the temperature field depends on m, on u and")
    L("    on cp, and every one of those enters the same exponential.")
    L("")

    L("[3] one axis free, the other nine at their centre")
    L("")
    L("    If a single free axis already gives a Phi enclosure spanning zero,")
    L("    then no amount of corner enumeration is a proof and neither is a")
    L("    slice-by-slice argument.")
    L("")
    L("    axis          Phi width Pa    implied dm kg/s    as pct of m")
    dphidm = {}
    for i, n in enumerate(C.NAMES):
        row = []
        for name, loop, m0 in (("P", P, m_p), ("M", M, m_m)):
            x = [Iv(v, v) for v in C.X0]
            x[i] = Iv(C.BOUNDS[i][0], C.BOUNDS[i][1])
            tin = Iv(C.T_IN_REF, C.T_IN_REF)
            if n == "dTin_" + name:
                tin = Iv(C.T_IN_REF + C.BOUNDS[i][0],
                         C.T_IN_REF + C.BOUNDS[i][1])
                x[i] = Iv(C.X0[i], C.X0[i])
            try:
                b = march_iv(loop, Iv(m0, m0), Iv(6000.0, 6000.0),
                             tin, **kw_iv(x, name))
                row.append((b["dp_buoy"] - b["dp_fric"]).width())
            except ValueError:
                row.append(float("nan"))
        w = max(row)
        slope = 2.0 * 5000.0 / 0.273          # d(dp_fric)/dm, order of magnitude
        L("    %-11s  %12.4g  %15.3g  %14.2f"
          % (n, w, w / slope, 100.0 * (w / slope) / 0.273))
        dphidm[n] = w
    L("")
    L("[4] what a certificate would cost")
    L("")
    L("    A sign test needs the enclosure narrower than the effect being")
    L("    resolved, which is about 0.1 pp of D_j, i.e. about 0.03 pct of m.")
    L("    The table above shows the enclosure of a SINGLE free axis is")
    L("    already 10-100 pct of m.  Halving an axis halves its enclosure, so")
    L("    each axis needs roughly 8-64 subdivisions, and the ten axes must be")
    L("    subdivided together: 8^10 to 64^10 boxes.  That is not a computing")
    L("    budget, it is a different method.")
    L("")
    L("    This is why the report says 'searched extremum'.  It is not")
    L("    caution about the search; it is the measured cost of the")
    L("    alternative.")
    L("")
    L("  wrote certify_v2_log.txt")
    (HERE / "certify_v2_log.txt").write_text("\n".join(LOG) + "\n",
                                             encoding="utf-8")


HERE = __import__("pathlib").Path(__file__).resolve().parent


if __name__ == "__main__":
    main()
