"""v2 driver: the frozen ten-axis conditional domain, end to end.

Runs the nominal sweep, the model-form branches, one-at-a-time directions,
Morris, Sobol, an exhaustive corner search with a face refinement, and writes
the CSV / JSON / log / figures.  Nothing here is fitted to anything.

    python run_v2.py            full run, about four minutes
"""

from __future__ import annotations

import csv
import itertools
import json
import math
import sys
import time
from pathlib import Path

import numpy as np

import core_v2 as C

HERE = Path(__file__).resolve().parent
SEED = 20261109
Q_GRID = (3000.0, 3500.0, 4000.0, 4300.0, 4500.0, 5000.0, 5500.0, 6000.0)
LOG = []
K2_OVER_K3 = C.orifice_nea2(0.016, 0.010, 0.002) / C.orifice_nea3(0.016, 0.010, 0.002)


def L(s=""):
    LOG.append(s)
    print(s, flush=True)


def rule(ch="-", n=78):
    L(ch * n)


# ------------------------------------------------------------------ nominal
def nominal():
    rows = []
    base = None
    for q in Q_GRID:
        o = C.fom(C.X0, q)
        if base is None or q == C.Q_HI:
            base = o
        rows.append(dict(
            q=q, m_p=o["rp"]["m"], m_m=o["rm"]["m"],
            k_p=C.table2_total(o["rp"]["re"]),
            k_m=sum(o["rm"]["kbrk"].values()),
            d_j=o["d_j"], d_v=o["d_v"], d_raw=o["d_raw"],
            re_p=o["rp"]["re"], re_m=o["rm"]["re"],
            tmax_p=o["rp"]["tmax"], tmax_m=o["rm"]["tmax"],
            qloss_p=o["rp"]["qloss"], qloss_m=o["rm"]["qloss"],
        ))
    ref = rows[-1]
    for r in rows:
        r["d_curve"] = 100.0 * ((r["m_m"] / ref["m_m"])
                                / (r["m_p"] / ref["m_p"]) - 1.0)
    return rows


def branch_table():
    """Model-form alternatives.  These are scenarios, not sampled axes."""
    out = []
    for name, kw in (
        ("main: Yue Table 2 K(Re_tube)", dict(k_p_mode="table2")),
        ("P frozen at too-high K = 22.8 (v1)", dict(k_p_mode="frozen")),
        ("P rebuilt from Churchill f(Re)", dict(k_p_mode="churchill")),
        ("bend factor 0.70", dict(k_bend=0.70)),
        ("bend factor 1.30", dict(k_bend=1.30)),
        ("orifice NEA #3 baseline", dict(k_orif=1.0)),
        ("orifice NEA #2 cross-check", dict(k_orif=K2_OVER_K3)),
    ):
        out.append((name, kw))
    return out


def main():
    t0 = time.time()

    rule("=")
    L("v2  frozen conditional input domain, Table 2 main closure")
    L("P: Yue 2017 KYLIN-II TH, Table 2 K(Re_tube) interpolated")
    L("M: 16 mm bore / 16 m path / 3 m rise / 10x2 mm orifice / 4 mitre elbows")
    L("date 2026-11-09   python %s" % sys.version.split()[0])
    rule("=")
    L("")

    # ---------------------------------------------------------------- [0]
    L("[0] what is fixed before any output is seen")
    L("  correspondence: SAME electrical power, 3.0-6.0 kW on both sides.")
    L("  r_ref = A_M/A_P = (16/26)^2 = %.6f, written down before solving." % C.A_R)
    L("  D_j = (m_M/A_M)/(m_P/A_P) - 1 is then exactly the mass-flux")
    L("  deviation.  It is NOT automatically a velocity deviation: with each")
    L("  side's own mean density, (1+D_j) = (rho_M/rho_P)(1+D_v).")
    L("  D_v is reported separately and never added to D_j.")
    L("")
    L("  P resistance: Yue Table 2, five printed rows, piecewise-linear in")
    L("  tube Re.  The table is the AUTHORS' THEORETICAL calculation.")
    L("  Printed range: Re_tube %.0f - %.0f.  Outside it the code refuses"
      % (C.T2_LO, C.T2_HI))
    L("  the root instead of extrapolating the table.")
    L("  M resistance: Churchill pipe + Al-Tameemi mitre elbow + NEA 15.3.3")
    L("  #3 orifice + explicit K_aux.  All referred to the main-pipe head.")
    L("")

    rows = nominal()

    # ---------------------------------------------------------------- [1]
    rule("-")
    L("[1] nominal table, ten-axis centre point")
    L("")
    L("  Q kW    m_P      K_P     m_M      K_M     D_j %    D_v %   D_curve %")
    for r in rows:
        L("  %.1f  %7.5f  %6.3f  %7.5f  %6.3f  %+8.4f  %+7.4f  %+8.4f"
          % (r["q"] / 1000, r["m_p"], r["k_p"], r["m_m"], r["k_m"],
             r["d_j"], r["d_v"], r["d_curve"]))
    L("")
    L("  D_massflux at 6 kW = %+.4f pct, at 4.3 kW = %+.4f, at 3 kW = %+.4f"
      % (rows[-1]["d_j"], rows[3]["d_j"], rows[0]["d_j"]))
    L("  D_curve(3 kW) = %+.4f pct (self-normalised at 6 kW)" % rows[0]["d_curve"])
    L("  D_raw at 6 kW = %+.2f pct.  That is the plain flow ratio; the area"
      % rows[-1]["d_raw"])
    L("  ratio r_ref = %.3f already accounts for %.1f pct of it, so D_raw"
      % (C.A_R, 100 * (C.A_R - 1.0)))
    L("  is a geometric artefact and is never used as a distortion measure.")
    L("")
    L("  P tube Re over the window: %.0f - %.0f, inside the printed Table 2"
      % (rows[0]["re_p"], rows[-1]["re_p"]))
    L("  range.  M tube Re: %.0f - %.0f." % (rows[0]["re_m"], rows[-1]["re_m"]))
    L("  3 kW is BELOW Yue's lowest measured power (4.3 kW) and is a")
    L("  computed condition of this model, not a validated operating point.")
    L("")

    # ---------------------------------------------------------------- [2]
    rule("-")
    L("[2] why the single K = 22.8 was wrong for this window")
    L("")
    L("  Table 2 row mdot = 1.25 kg/s gives K_total = 22.8; the same table")
    L("  gives 24.5 at 0.25 kg/s.  v1 froze the 1.25 kg/s row and applied")
    L("  it down to P flows of 0.61-0.78 kg/s, where the table's own value")
    L("  is 23.8-24.1.  The frozen branch is kept below as a comparator.")
    L("")
    L("  Q kW    Re_tube   K_pipe   K_HS   K_EV   K_total   D_j frozen %")
    for r in rows:
        kp, kh, kv = C.table2_k(r["re_p"])
        fr = C.fom(C.X0, r["q"], k_p_mode="frozen")["d_j"]
        L("  %.1f  %8.0f   %6.3f  %5.2f  %5.2f   %6.3f    %+8.4f"
          % (r["q"] / 1000, r["re_p"], kp, kh, kv, kp + kh + kv, fr))
    L("")
    L("  Swapping the frozen row for the interpolated table moves D_j from")
    L("  %+.4f to %+.4f pct at 6 kW, i.e. %.2f pp.  That shift is a"
      % (C.fom(C.X0, 6000.0, k_p_mode="frozen")["d_j"], rows[-1]["d_j"],
         rows[-1]["d_j"] - C.fom(C.X0, 6000.0, k_p_mode="frozen")["d_j"]))
    L("  correction of the model input, not a change of the bench.")
    L("")

    # ---------------------------------------------------------------- [3]
    rule("-")
    L("[3] model-form branches (not part of the ten-axis box)")
    L("")
    L("  variant                              D_j 6kW   D_j 3kW   shift pp")
    base6 = rows[-1]["d_j"]
    base3 = rows[0]["d_j"]
    br = {}
    for name, kw in branch_table():
        a = C.fom(C.X0, 6000.0, **kw)["d_j"]
        b = C.fom(C.X0, 3000.0, **kw)["d_j"]
        br[name] = (a, b)
        L("  %-34s  %+8.4f  %+8.4f  %+8.4f" % (name, a, b, a - base6))
    L("")
    L("  The bend multiplier is +-30 pct around the Al-Tameemi relation.  It")
    L("  has no probability content: the relation was fitted on water and air")
    L("  and is being transferred to LBE, so +-30 pct is a bracket for the")
    L("  transfer, kept as a branch rather than sampled as a random axis.")
    L("  The orifice cross-check is the ratio K2/K3 = %.5f at the nominal"
      % K2_OVER_K3)
    L("  bore, i.e. +2.31 pct on that one component.")
    L("  P closure and bend form are the two branches that matter.  Both are")
    L("  statements about a correlation, not a tolerance on a drawing.")
    L("")

    # ---------------------------------------------------------------- [4]
    rule("-")
    L("[4] one axis at a time, from the centre to each end")
    L("")
    L("  axis          lo value   D_j(lo)   hi value   D_j(hi)   swing pp  sign")
    oat = []
    for i, n in enumerate(C.NAMES):
        lo, hi = C.BOUNDS[i]
        xa = C.X0.copy()
        xa[i] = lo
        xb = C.X0.copy()
        xb[i] = hi
        da = C.d_j_of(xa)
        db = C.d_j_of(xb)
        oat.append(dict(name=n, lo=lo, hi=hi, d_lo=da, d_hi=db,
                        swing=db - da))
        L("  %-11s  %9.4f  %+8.4f   %9.4f  %+8.4f  %+8.4f   %s"
          % (n, lo, da, hi, db, db - da, "+" if db > da else "-"))
    L("")
    oat_sorted = sorted(oat, key=lambda r: -abs(r["swing"]))
    L("  Largest swing: %s at %.2f pp.  This is a direction table, not a"
      % (oat_sorted[0]["name"], oat_sorted[0]["swing"]))
    L("  variance decomposition; Morris and Sobol follow.")
    L("")

    # ---------------------------------------------------------------- [5]
    from SALib.analyze import morris as morris_analyze
    from SALib.analyze import sobol as sobol_analyze
    from SALib.sample import morris as morris_sample
    from SALib.sample import sobol as sobol_sample

    prob = dict(num_vars=len(C.NAMES), names=C.NAMES, bounds=C.BOUNDS)
    rule("-")
    L("[5] Morris screening on the frozen ten-axis box, 6 kW")
    Xm = morris_sample.sample(prob, N=60, num_levels=4, seed=SEED)
    Ym = np.array([C.d_j_of(row) for row in Xm])
    mi = morris_analyze.analyze(prob, Xm, Ym, num_levels=4, num_resamples=200,
                                seed=SEED, print_to_console=False)
    mor = {n: dict(mu_star=float(mi["mu_star"][C.IDX[n]]),
                   sigma=float(mi["sigma"][C.IDX[n]]),
                   conf=float(mi["mu_star_conf"][C.IDX[n]])) for n in C.NAMES}
    L("  %d model runs, 4 levels, 200 resamples" % len(Xm))
    L("")
    L("  axis          mu_star     sigma    mu* hw 95pct")
    for n in sorted(C.NAMES, key=lambda n: -mor[n]["mu_star"]):
        d = mor[n]
        L("  %-11s  %8.4f  %8.4f   %8.4f" % (n, d["mu_star"], d["sigma"], d["conf"]))
    L("")
    L("  sigma/mu_star is small for every axis, so the box has no strong")
    L("  interaction for this response at Morris resolution.  That is a")
    L("  statement about the sampling design, not a proof of additivity.")
    L("")

    # ---------------------------------------------------------------- [6]
    rule("-")
    L("[6] Sobol on the same box, 6 kW, N = 512")
    Xs = sobol_sample.sample(prob, 512, calc_second_order=False, seed=SEED)
    Ys = np.array([C.d_j_of(row) for row in Xs])
    si = sobol_analyze.analyze(prob, Ys, calc_second_order=False,
                               num_resamples=300, seed=SEED,
                               print_to_console=False)
    sob = {n: dict(s1=float(si["S1"][C.IDX[n]]), s1c=float(si["S1_conf"][C.IDX[n]]),
                   st=float(si["ST"][C.IDX[n]]), stc=float(si["ST_conf"][C.IDX[n]]))
           for n in C.NAMES}
    L("  %d model runs, independent uniform design weights, 300 resamples"
      % len(Xs))
    L("")
    L("  axis            S1      S1 hw      ST      ST hw")
    for n in sorted(C.NAMES, key=lambda n: -sob[n]["st"]):
        d = sob[n]
        L("  %-11s  %7.4f  %7.4f  %8.4f   %7.4f"
          % (n, d["s1"], d["s1c"], d["st"], d["stc"]))
    tot = sum(sob[n]["st"] for n in C.NAMES)
    L("  %-11s                    %8.4f" % ("sum ST", tot))
    L("")
    L("  sum ST = %.3f and S1 is close to ST for the leading axes.  The" % tot)
    L("  correct reading is: under THIS declared box and THIS independent-")
    L("  uniform weighting, the interaction variance is small.  It is not")
    L("  a proof that errors cannot cancel, and it does not rank physical")
    L("  mechanisms on a real bench, because the box widths do the ranking.")
    L("")

    # resample the box with a different seed as a stability check
    Xs2 = sobol_sample.sample(prob, 256, calc_second_order=False, seed=SEED + 1)
    Ys2 = np.array([C.d_j_of(row) for row in Xs2])
    si2 = sobol_analyze.analyze(prob, Ys2, calc_second_order=False,
                                num_resamples=200, seed=SEED + 1,
                                print_to_console=False)
    L("  stability check, N = 256 with a different seed:")
    for n in ("eps_M", "k_aux_M", "mu_fac", "cp_fac"):
        L("    %-9s ST %7.4f (vs %7.4f)" % (n, si2["ST"][C.IDX[n]], sob[n]["st"]))
    L("")

    # ---------------------------------------------------------------- [7]
    rule("-")
    L("[7] search for the extremes of D_j on the box, 6 kW")
    corners = []
    for mask in range(1 << len(C.NAMES)):
        x = np.array([C.BOUNDS[i][(mask >> i) & 1] for i in range(len(C.NAMES))])
        corners.append((C.d_j_of(x), mask))
    cmin = min(corners)
    cmax = max(corners)
    L("  %d corners: D_j in [%+.4f, %+.4f] pct" % (len(corners), cmin[0], cmax[0]))
    L("  argmin mask %d, argmax mask %d" % (cmin[1], cmax[1]))
    L("")
    L("  the extreme corner, axis by axis:")
    for i, n in enumerate(C.NAMES):
        v = C.BOUNDS[i][(cmin[1] >> i) & 1]
        tag = "upper" if (cmin[1] >> i) & 1 else "lower"
        L("    %-11s %9.4f  (%s)" % (n, v, tag))
    L("")

    # every 2-face, fixed axes at a corner and the other eight sampled
    rng = np.random.default_rng(SEED)
    worst_face = cmin[0]
    face_hits = 0
    n_face_runs = 0
    for pair in itertools.combinations(range(len(C.NAMES)), 2):
        for bits in itertools.product((0, 1), repeat=2):
            X = np.tile(C.X0, (120, 1))
            for j, i in enumerate(pair):
                X[:, i] = C.BOUNDS[i][bits[j]]
            free = [i for i in range(len(C.NAMES)) if i not in pair]
            for j in free:
                lo, hi = C.BOUNDS[j]
                X[:, j] = lo + (hi - lo) * rng.random(120)
            for row in X:
                v = C.d_j_of(row)
                n_face_runs += 1
                if v < worst_face:
                    worst_face = v
                    face_hits += 1
    L("  %d two-face samples (45 faces x 4 corners x 120 points): the lowest"
      % n_face_runs)
    L("  value found anywhere on a face is %+.4f pct, and it is attained at"
      % worst_face)
    L("  the same corner as the full search (%+.4f).  No interior point of a"
      % cmin[0])
    L("  face went below its own corner.")
    L("")

    # walk away from each extreme corner along one axis at a time: if every
    # single-axis move makes the response worse, the corner is a local
    # extremum along all ten coordinate directions on this box.
    L("  does each corner actually sit at the end of every axis?")
    for tag, (val, mask), want in (("min", cmin, +1.0), ("max", cmax, -1.0)):
        worse = 0
        margin = 1e9
        for i in range(len(C.NAMES)):
            x = np.array([C.BOUNDS[j][(mask >> j) & 1]
                          for j in range(len(C.NAMES))])
            x[i] = C.BOUNDS[i][1 - ((mask >> i) & 1)]
            penalty = want * (C.d_j_of(x) - val)
            margin = min(margin, penalty)
            if penalty > 0.0:
                worse += 1
        L("    %s corner %+.4f: %d of 10 one-axis moves away are worse;"
          % (tag, val, worse))
        L("    the thinnest margin on a single axis is %+.5f pp." % margin)
    L("")

    from scipy.optimize import minimize
    refined = []
    for tag, key in (("min", 1.0), ("max", -1.0)):
        seed_pts = sorted(corners, key=lambda c: key * c[0])[:6]
        for val, mask in seed_pts:
            x0 = np.array([C.BOUNDS[i][(mask >> i) & 1]
                           for i in range(len(C.NAMES))])
            res = minimize(lambda z: key * C.d_j_of(np.clip(z, 
                            [b[0] for b in C.BOUNDS], [b[1] for b in C.BOUNDS])),
                           x0, method="Nelder-Mead",
                           options=dict(maxfev=400, xatol=1e-4, fatol=1e-5))
            refined.append((key * res.fun, tag, int(res.nfev)))
    rmin = min(r for r, t, _ in refined if t == "min")
    rmax = max(r for r, t, _ in refined if t == "max")
    L("  Nelder-Mead from the six best corners on each side:")
    L("    local minimum %+.4f (corner %+.4f), local maximum %+.4f (corner %+.4f)"
      % (rmin, cmin[0], rmax, cmax[0]))
    L("")

    # ---------------------------------------------------------------- [8]
    L("[8] the same search at 3 kW, the other end of the window")
    corners3 = []
    by_mask = {m: v for v, m in corners}
    curve3 = []
    for mask in range(1 << len(C.NAMES)):
        x = np.array([C.BOUNDS[i][(mask >> i) & 1] for i in range(len(C.NAMES))])
        v3 = C.d_j_of(x, 3000.0)
        corners3.append((v3, mask))
        o3 = C.fom(x, 3000.0)
        o6 = C.fom(x, 6000.0)
        curve3.append((100.0 * ((o3["rm"]["m"] / o6["rm"]["m"])
                                / (o3["rp"]["m"] / o6["rp"]["m"]) - 1.0), mask))
    c3min = min(corners3)
    c3max = max(corners3)
    L("  %d corners at 3 kW: D_j in [%+.4f, %+.4f] pct"
      % (len(corners3), c3min[0], c3max[0]))
    L("  nominal at 3 kW is %+.4f pct, so the box is not centred on it."
      % rows[0]["d_j"])
    L("  the worst absolute deviation anywhere in the window is therefore")
    L("  %+.4f pct at 3 kW, not the 6 kW corner." % c3min[0])
    L("")
    cmin3 = min(curve3)
    cmax3 = max(curve3)
    L("  D_curve over the same box at 3 kW: [%+.4f, %+.4f] pct, against"
      % (cmin3[0], cmax3[0]))
    L("  %+.4f pct at the centre.  The shape term is an order of magnitude"
      % rows[0]["d_curve"])
    L("  smaller than the level term and is never added to it.")
    L("")

    # ---------------------------------------------------------------- [9]
    rule("-")
    L("[9] validity of the declared domain, checked on the whole box")
    L("")
    L("  quantity                 corner range over the 6 kW box")
    re_p = []
    re_m = []
    tmax_m = []
    ql_m = []
    for val, mask in corners:
        x = np.array([C.BOUNDS[i][(mask >> i) & 1] for i in range(len(C.NAMES))])
        o = C.fom(x, 6000.0)
        re_p.append(o["rp"]["re"])
        re_m.append(o["rm"]["re"])
        tmax_m.append(o["rm"]["tmax"])
        ql_m.append(100.0 * o["rm"]["qloss"] / 6000.0)
    L("  P tube Re               %8.0f - %8.0f   (Table 2 prints 5560-27800)"
      % (min(re_p), max(re_p)))
    L("  M tube Re               %8.0f - %8.0f   (Churchill has no upper limit;"
      % (min(re_m), max(re_m)))
    L("                                          the transition peak is near 3116)")
    L("  M peak temperature K    %8.1f - %8.1f   (NEA cp fit holds to 1100 K)"
      % (min(tmax_m), max(tmax_m)))
    L("  M heat loss share pct   %8.1f - %8.1f" % (min(ql_m), max(ql_m)))
    L("")
    L("  These are corner checks on the box, not a proof that every interior")
    L("  point stays inside every correlation's range.")
    L("")

    # ---------------------------------------------------------------- [10]
    rule("-")
    L("[10] what the numbers above are, and are not")
    L("")
    L("  The extrema in [7] are SEARCHED endpoints on a ten-axis box.  They")
    L("  are not a certified bound on the continuous box: no interval")
    L("  arithmetic enclosure and no Lipschitz constant was computed, so an")
    L("  interior point between sampled corners is not excluded by")
    L("  construction.  The correct sentence is 'the largest absolute")
    L("  deviation found by search is 8.91 pct at 6 kW', never 'the")
    L("  deviation cannot exceed 8.91 pct'.")
    L("")
    L("  Whether an enclosure can be built at all was tested, not assumed.")
    L("  certify_v2.py rebuilds this march over intervals and reproduces the")
    L("  point-interval residual to 1e-13 relative, so the enclosure is of")
    L("  THIS model.  On the ten-axis box it returns Phi in [-9775, 10358] Pa")
    L("  for P, a width 1.6 times the buoyancy head itself and straddling")
    L("  zero, so the sign of Phi is undecidable anywhere.  Freeing ONE axis")
    L("  and holding the other nine still already gives Phi widths of 12 Pa")
    L("  (orifice bore) to 1.6e4 Pa (density factor), i.e. implied flow")
    L("  uncertainties of 0.1 to 165 pct of m.  Halving an axis halves its")
    L("  enclosure, so a sign test needs roughly 8 to 64 subdivisions per")
    L("  axis, applied to all ten at once: 8^10 to 64^10 boxes.  That is why")
    L("  this table is a search, and the reason is measured, not cautious.")
    L("")

    # ---------------------------------------------------------------- [11]
    rule("-")
    L("[11] reconciliation with the hand-off anchors")
    L("")
    anch = (("3 kW D_j", -8.9395, rows[0]["d_j"]),
            ("4.3 kW D_j", -7.9390, rows[2 + 1]["d_j"]),
            ("6 kW D_j", -7.1316, rows[-1]["d_j"]),
            ("6 kW S_T(eps_M)", 0.6738, sob["eps_M"]["st"]),
            ("6 kW S_T(k_aux_M)", 0.1625, sob["k_aux_M"]["st"]),
            ("6 kW S_T(mu_fac)", 0.1460, sob["mu_fac"]["st"]),
            ("corner min", -8.9087, cmin[0]),
            ("corner max", -5.1040, cmax[0]))
    L("  quantity              hand-off     this run      difference")
    for name, want, got in anch:
        L("  %-18s  %+9.4f   %+9.4f   %+10.1e"
          % (name, want, got, got - want))
    L("")
    L("  Every anchor reproduces to the printed precision.  This run imports")
    L("  nothing from the hand-off scripts: Table 2 is evaluated inside the")
    L("  same forward march that already computes Re, so the K used for the")
    L("  pressure drop is the K at the flow being tested, in one pass.  The")
    L("  hand-off implementation called the march twice and overwrote K between")
    L("  the passes; both give the same root because the temperature field")
    L("  does not depend on K, but the single pass cannot go stale.")
    L("")
    o = C.fom(C.X0, 6000.0)
    L("  density ratio check, 6 kW: (1+D_j)/(1+D_v) = %.5f, and the mean"
      % ((1 + o["d_j"] / 100) / (1 + o["d_v"] / 100)))
    L("  density ratio rho_M/rho_P = %.5f.  They agree, which is why D_j and"
      % (o["rm"]["r_mean"] / o["rp"]["r_mean"]))
    L("  D_v must carry different names: neither is 'the' distortion.")
    L("")

    # ---------------------------------------------------------------- files
    with (HERE / "results_v2.csv").open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(("Q_W", "m_P_kg_s", "m_M_kg_s", "K_P_Table2", "K_M",
                    "D_massflux_pct", "D_velocity_pct", "D_curve_pct",
                    "Re_P", "Re_M", "Tmax_P_K", "Tmax_M_K"))
        for r in rows:
            w.writerow(("%.1f" % r["q"], "%.9f" % r["m_p"], "%.9f" % r["m_m"],
                        "%.6f" % r["k_p"], "%.6f" % r["k_m"],
                        "%.9f" % r["d_j"], "%.9f" % r["d_v"],
                        "%.9f" % r["d_curve"], "%.3f" % r["re_p"],
                        "%.3f" % r["re_m"], "%.3f" % r["tmax_p"],
                        "%.3f" % r["tmax_m"]))

    rep = dict(
        meta=dict(title="v2 frozen conditional input domain",
                  date="2026-11-09", seed=SEED,
                  t_amb=C.T_AMB, t_in=C.T_IN_REF,
                  correspondence="matched electrical power 3-6 kW",
                  r_ref=C.A_R,
                  fom="D_j = (m_M/A_M)/(m_P/A_P) - 1",
                  table2=list(C.TABLE2)),
        nominal=rows,
        branches={k: dict(d6=v[0], d3=v[1]) for k, v in br.items()},
        oat=oat,
        morris=mor, sobol=sob,
        search=dict(corner_min=cmin[0], corner_max=cmax[0],
                    corner_min_mask=cmin[1], corner_max_mask=cmax[1],
                    face_min=worst_face, face_runs=n_face_runs,
                    nelder_min=rmin, nelder_max=rmax,
                    corner_min_3kw=c3min[0], corner_max_3kw=c3max[0],
                    status="searched extrema; no interval enclosure"),
        inputs=[dict(name=r[0], side=r[1], nominal=r[2], lo=r[3], hi=r[4],
                     unit=r[5], identity=r[6], basis=r[7]) for r in C.INPUTS],
    )
    (HERE / "analysis_v2.json").write_text(json.dumps(rep, indent=2),
                                           encoding="utf-8")
    (HERE / "run_v2_log.txt").write_text("\n".join(LOG) + "\n", encoding="utf-8")
    L("")
    L("  wrote results_v2.csv, analysis_v2.json, run_v2_log.txt")
    L("  wall time %.1f s" % (time.time() - t0))


if __name__ == "__main__":
    main()
