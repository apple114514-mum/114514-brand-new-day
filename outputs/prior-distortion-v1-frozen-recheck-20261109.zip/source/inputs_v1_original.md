# v1 declared P/M input tables

Compiled 2026-11-09. Every number carries a tag: **src** = published,
**calc** = a correlation or a geometry evaluated here, **decl** = an
independent design declaration of this study. Nothing is balanced to a
scaling law, to `K=22.8`, or to a measured flow.

## 1. Common boundary

| item | value | tag | note |
|---|---:|---|---|
| ambient temperature | 293.15 K | decl | one declared room value |
| heater inlet | 473.15 K | decl | controlled boundary, both sides |
| LBE properties | NEA 2015 Table 2.19.3 | src | PDF p131 |
| insulation | 50 mm, k=0.05 W/(m K), +20% bridge | decl | U' per segment |
| reference ratio r_ref | A_M/A_P = 0.378698 | decl | same-v, fixed a priori |

## 2. P: Yue 2017 KYLIN-II TH

| segment | kind | L / m | flow area / mm2 | Dh / mm | dz / m |
|---|---|---:|---:|---:|---:|
| P-HS-act | ann | 0.80 | 1910.1 | 32.00 | +0.80 |
| P-HS-top | ann | 1.00 | 1910.1 | 32.00 | +1.00 |
| P-riser | pipe | 3.20 | 530.9 | 26.00 | +3.20 |
| P-top | pipe | 0.50 | 530.9 | 26.00 | +0.00 |
| P-HX | pipe | 1.50 | 530.9 | 26.00 | -1.50 |
| P-down | pipe | 3.50 | 530.9 | 26.00 | -3.50 |
| P-bot | pipe | 0.50 | 530.9 | 26.00 | +0.00 |

Resistance: **Yue Table 2** at 1.25 kg/s, all referred to the
main-pipe dynamic head: `K_pipe` 17.7, `K_HS` 2.6, `K_EV` 2.5,
total 22.8. Held frozen in `m`: the published decomposition cannot
be inverted to a unique `f(Re)` law (claim C-34), so re-scaling it
would be an invention. The gap is carried as `k_P_fac` instead.

The 5 m total height and the 1.8 m / 1.5 m exchanger lengths are
published. The 0.5 m horizontal branches are **derived** from
`L_total` = 11 m (Yue: *assumed conservatively*) minus 2 x 5 m, and
are flagged as a declaration, not a measurement.

## 3. M: the declared candidate bench

| segment | kind | L / m | flow area / mm2 | Dh / mm | dz / m |
|---|---|---:|---:|---:|---:|
| M-HS | pipe | 1.00 | 201.1 | 16.00 | +1.00 |
| M-riser | pipe | 2.00 | 201.1 | 16.00 | +2.00 |
| M-top | pipe | 5.00 | 201.1 | 16.00 | +0.00 |
| M-cooler | pipe | 1.00 | 201.1 | 16.00 | -1.00 |
| M-down | pipe | 2.00 | 201.1 | 16.00 | -2.00 |
| M-bottom | pipe | 5.00 | 201.1 | 16.00 | +0.00 |

Friction is distributed: Churchill per segment, four 90 deg mitre
elbows (Al-Tameemi-Ricco Eq 4), one 10 x 2 mm orifice (NEA 15.3.3
#3, `K`=5.593959 referred to the 16 mm head, valid `Re_D`>1e3 and
the declared Re is 7.9e3-1.1e4 so it is inside), plus `K_aux`.

## 4. Uncertainty inputs (the joint box for perturbation and GSA)

| key | side | nominal | range | unit | identity | basis |
|---|---|---:|---|---|---|---|
| `eps_M` | M | 10 | 0 - 20 | um | declared tube finish | 10 um is a procurement spec, not a measured Ra; ks != Ra |
| `k_P_fac` | P | 1 | 0.9 - 1.1 | - | P total-K provenance | a geometric rebuild of P gives 21.4 vs Yue 22.8 (-6 pct) |
| `k_bend_fac` | both | 1 | 0.7 - 1.3 | - | shared bend model form | Al-Tameemi-Ricco mitre elbow, water/air, transferred to LBE |
| `k_orif_fac` | M | 1 | 0.9 - 1.1 | - | orifice model form | NEA 15.3.3 #3 vs #2 differ by 2.31 pct; band widened to +-10 pct |
| `d_hole` | M | 10 | 9.98 - 10.02 | mm | declared hole tolerance | a drawing spec, not a capability claim |
| `k_aux_M` | M | 0.5 | 0 - 1 | - | unspecified M form loss | flanges, supports, instrument pockets; no correlation available |
| `u_loss_fac` | both | 1 | 0.8 - 1.2 | - | insulation + bridges | 50 mm, k=0.05, +20 pct bridge allowance; ageing not measured |
| `mu_fac` | both | 1 | 0.92 - 1.08 | - | NEA mu estimated error | Table 2.19.3, +-8 pct, 400-1200 K |
| `cp_fac` | both | 1 | 0.93 - 1.07 | - | NEA cp estimated error | Table 2.19.3, +-7 pct, 400-1100 K |
| `rho_fac` | both | 1 | 0.992 - 1.008 | - | NEA rho estimated error | Table 2.19.3, +-0.8 pct, 400-1300 K |
| `dTin_P` | P | 0 | -2 - 2 | K | control error, P | declared setpoint accuracy of the controlled heater inlet |
| `dTin_M` | M | 0 | -2 - 2 | K | control error, M | declared setpoint accuracy of the controlled heater inlet |
| `L_HS_M` | M | 1 | 0.99 - 1.01 | m | heater length tolerance | declared fabrication tolerance |

These are **analysis weights on a declared design domain**, not a
measured population. The three property factors are applied to both
sides (common mode) in the main run; the independent mode is a
separate, reported branch.
