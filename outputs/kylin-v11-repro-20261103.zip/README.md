# v11 原始脚本复现包
解压后执行 python closure_v11.py。原始 379 行数值复现；解释以仓库同日 v11-review 为准。
