物理参数域研究交接包（2026-11-06）

先读 outputs/physical-parameter-domain-handoff-20261106.md。
其第 5 节列出建议阅读顺序；包内包含所列原文 PDF、复核报告和 paper-workspace/claim-matrix.md。

给 DeepSeek 时可直接上传本 ZIP；如果对方不能读取 ZIP，先解压，再上传交接 MD 和相关原文 PDF。
所有模型数值请按交接文档中的“条件结果”理解，不要当成装置实测参数域。
